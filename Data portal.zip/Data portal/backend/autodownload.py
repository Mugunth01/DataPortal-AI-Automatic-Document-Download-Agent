"""
autodownload.py  ─  Sequential county CSV/XLSX downloader
----------------------------------------------------------
ALL timestamps use IST (Asia/Kolkata, UTC+5:30).

Strict per-county workflow (no batching):
  For EVERY county, one at a time:
    1. Download file  (HTTP w/ proxy  OR  Playwright w/o proxy)
    2. Update DB      (insert staging → run SP)
    3. Write sidecar  (JSON log next to file)
    4. Log separator
    5. Move to next county
"""

import csv
import io
import json
import os
import re
import time
import logging
import requests
import pyodbc
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo          # Python 3.9+
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

# Load .env credentials
load_dotenv()


# ─────────────────────────────────────────────────────────────────
#  IST TIMEZONE
# ─────────────────────────────────────────────────────────────────
IST = ZoneInfo("Asia/Kolkata")

def now_ist() -> datetime:
    return datetime.now(tz=IST)

def now_ist_str(fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    return now_ist().strftime(fmt)

def now_ist_iso() -> str:
    return now_ist().isoformat()

def now_ist_file_stamp() -> str:
    """Timestamp string safe for filenames: YYYYMMDD_HHMMSS (IST)."""
    return now_ist().strftime("%Y%m%d_%H%M%S")


# ─────────────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────────────
INTERVAL_MINUTES = 1

BASE_PATH = r"\\sanserver\PFBA Fileserver\Software Engineering\Taxroll_Data\Team Details\Backup\Mugunthan\hackthon"

CONN_STR = (
    "DRIVER={ODBC Driver 13 for SQL Server};"
    "SERVER=taxrollstage-db;"
    "DATABASE=TaxrollStaging;"
    "Trusted_Connection=yes;"
)

# ── Proxy credentials (HTTP counties only) ────────────────────────
PROXY_HOST = "proxy.geonode.io"
PROXY_PORT = "9000"
PROXY_USER = "geonode_cc9z3oksYO"
PROXY_PASS = "85219dd4-2491-437f-89fb-08b57d45d9c3"

PROXIES = {
    "http":  f"http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}",
    "https": f"http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}",
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
}

# ── county_code → DB county name ──────────────────────────────────
COUNTY_MAP = {
    # HTTP
    "bellcad":       "Bell",
    "starrcad":      "Starr",
    "browncad":      "Brown",
    "brookscad":     "Brooks",
    "brewstercotad": "Brewster",
    # Playwright
    "elliscad":      "Ellis",
    "hidalgoad":     "Hidalgo",
    "prad":          "Potter-Randall",
    "rockwallcad":   "Rockwall",
    "webbcad":       "Webb",
    "dentoncad":     "Denton",
    "mcad-tx":       "MCAD",
    "travis":        "Travis",
}


# ─────────────────────────────────────────────────────────────────
#  COUNTY QUEUE
#
#  Single ordered list of all 13 counties.
#  Each dict has:
#    strategy    : "http" | "playwright"
#    county_code : key into COUNTY_MAP
#
#  HTTP-only keys  : base_url, agent_codes, year
#  Playwright keys : name, url, username, password
# ─────────────────────────────────────────────────────────────────
EMAIL = os.getenv("EMAIL")

COUNTY_QUEUE = [
    # ── HTTP counties (requests + proxy) ──────────────────────────
    {
        "strategy":    "http",
        "county_code": "bellcad",
        "name":        "Bell",
        "base_url":    "https://esearch.bellcad.org/",
        "agent_codes": "581950",
        "year":        "2026",
    },
    {
        "strategy":    "http",
        "county_code": "brewstercotad",
        "name":        "Brewster",
        "base_url":    "https://esearch.brewstercotad.org/",
        "agent_codes": "28350",
        "year":        "2026",
    },
    {
        "strategy":    "http",
        "county_code": "brookscad",
        "name":        "Brooks",
        "base_url":    "https://esearch.brookscad.org/",
        "agent_codes": "135069",
        "year":        "2025",
    },
    {
        "strategy":    "http",
        "county_code": "browncad",
        "name":        "Brown",
        "base_url":    "https://esearch.brown-cad.org/",
        "agent_codes": "89983",
        "year":        "2026",
    },
    {
        "strategy":    "http",
        "county_code": "starrcad",
        "name":        "Starr",
        "base_url":    "https://esearch.starrcad.org/",
        "agent_codes": "103283",
        "year":        "2025",
    },
    # ── Playwright counties (browser, NO proxy) ────────────────────
    {
        "strategy":    "playwright",
        "county_code": "elliscad",
        "name":        "Ellis",
        "url":         os.getenv("ELLIS_URL"),
        "username":    EMAIL,
        "password":    os.getenv("ELLIS_PASSWORD"),
    },
    {
        "strategy":    "playwright",
        "county_code": "hidalgoad",
        "name":        "Hidalgo",
        "url":         os.getenv("HIDALGO_URL"),
        "username":    EMAIL,
        "password":    os.getenv("HIDALGO_PASSWORD"),
    },
    {
        "strategy":    "playwright",
        "county_code": "prad",
        "name":        "Potter-Randall",
        "url":         os.getenv("POTTER_RANDALL_URL"),
        "username":    EMAIL,
        "password":    os.getenv("POTTER_RANDALL_PASSWORD"),
    },
    {
        "strategy":    "playwright",
        "county_code": "rockwallcad",
        "name":        "Rockwall",
        "url":         os.getenv("ROCKWALL_URL"),
        "username":    EMAIL,
        "password":    os.getenv("ROCKWALL_PASSWORD"),
    },
    {
        "strategy":    "playwright",
        "county_code": "webbcad",
        "name":        "Webb",
        "url":         os.getenv("WEBB_URL"),
        "username":    EMAIL,
        "password":    os.getenv("WEBB_PASSWORD"),
    },
    {
        "strategy":    "playwright",
        "county_code": "dentoncad",
        "name":        "Denton",
        "url":         os.getenv("DENTON_URL"),
        "username":    EMAIL,
        "password":    os.getenv("DENTON_PASSWORD"),
    },
    {
        "strategy":    "playwright",
        "county_code": "mcad-tx",
        "name":        "MCAD",
        "url":         os.getenv("MCAD_URL"),
        "username":    EMAIL,
        "password":    os.getenv("MCAD_PASSWORD"),
    },
    {
        "strategy":    "playwright",
        "county_code": "travis",
        "name":        "Travis",
        "url":         os.getenv("TRAVIS_URL"),
        "username":    EMAIL,
        "password":    os.getenv("TRAVIS_PASSWORD"),
    },
]


# ─────────────────────────────────────────────────────────────────
#  LOGGING
# ─────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

class ISTFormatter(logging.Formatter):
    def formatTime(self, record, datefmt=None):
        ct = datetime.fromtimestamp(record.created, tz=IST)
        if datefmt:
            return ct.strftime(datefmt)
        return ct.strftime("%Y-%m-%d %H:%M:%S IST")

for handler in logging.root.handlers:
    handler.setFormatter(ISTFormatter(
        fmt="%(asctime)s  %(levelname)-7s  %(message)s",
        datefmt="%H:%M:%S IST",
    ))


# ─────────────────────────────────────────────────────────────────
#  SHARED HELPERS
# ─────────────────────────────────────────────────────────────────
def get_property_id(row: dict) -> str | None:
    """
    Extract the property/account identifier from a row dict.
    Handles column names across both HTTP (CSV) and Playwright (XLSX) sources:
      - HTTP CSVs  : "PropertyId", "AccountNumber", "Account", etc.
      - Playwright : "Prop ID" (normalises to "propid")
    Priority: exact propid match first, then propertyid, then account.
    """
    normalised = {}
    for key in row:
        k = key.replace("ï»¿", "").lower().replace(" ", "").replace("_", "")
        normalised[k] = (key, row[key])

    # Check in priority order so "Prop ID" is caught before a broader "account" match
    for pattern in ("propid", "propertyid", "account"):
        for k, (orig_key, val) in normalised.items():
            if pattern in k and val is not None:
                return str(val).strip()
    return None


def write_sidecar(file_path: str, payload: dict):
    sidecar = file_path + ".log.json"
    try:
        with open(sidecar, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        log.info(f"📝 Sidecar written → {sidecar}")
    except Exception as e:
        log.warning(f"Could not write sidecar: {e}")


def _empty_stats() -> dict:
    return {
        "total_accounts":          0,
        "total_csv":               0,
        "datecoded_updated_count": 0,
        "datecoded_end_count":     0,
        "inserted_count":          0,
        "success_count":           0,
        "failure_count":           0,
        "success_pids":            [],
        "failure_pids":            [],
        "updated_pids":            [],
        "expired_pids":            [],
        "inserted_pids":           [],
    }


def _build_sidecar(status: str, db: dict, error: str = "") -> dict:
    payload = {
        "status":            status,
        "totalCsv":          db.get("total_csv", 0),
        "totalAccounts":     db.get("total_accounts", 0),
        "datecodedUpdated":  db.get("datecoded_updated_count", 0),
        "datecodedEndCount": db.get("datecoded_end_count", 0),
        "insertedCount":     db.get("inserted_count", 0),
        "successCount":      db.get("success_count", 0),
        "failureCount":      db.get("failure_count", 0),
        "successPids":       db.get("success_pids", []),
        "failurePids":       db.get("failure_pids", []),
        "updatedPids":       db.get("updated_pids", []),
        "expiredPids":       db.get("expired_pids", []),
        "insertedPids":      db.get("inserted_pids", []),
        "ts":                now_ist_iso(),
    }
    if error:
        payload["error"] = error
    return payload


# ─────────────────────────────────────────────────────────────────
#  PRE-SP STATS
# ─────────────────────────────────────────────────────────────────
def collect_pre_sp_stats(cursor, county_name_str: str, county_id: int, csv_pids: list[str]) -> dict:
    cursor.execute(
        "SELECT COUNT(*) FROM ptax_account_test WHERE CountyId = ?", county_id
    )
    total_accounts = cursor.fetchone()[0]

    cursor.execute(
        "SELECT AccountId, AccountNumber FROM ptax_account_test WHERE CountyId = ?",
        county_id,
    )
    db_rows        = cursor.fetchall()
    db_account_map = {r[1].strip(): r[0] for r in db_rows}
    db_acct_nums   = set(db_account_map.keys())

    csv_pids_set   = set(csv_pids)
    matched_pids   = [p for p in csv_pids if p in db_acct_nums]
    unmatched_pids = [p for p in csv_pids if p not in db_acct_nums]

    log.info(
        f"   CSV pids: {len(csv_pids)} | "
        f"Matched: {len(matched_pids)} | "
        f"Unmatched: {len(unmatched_pids)}"
    )

    cursor.execute("""
        SELECT a.AccountNumber
        FROM PTAX_AofA_Test t
        JOIN ptax_account_test a ON a.AccountId = t.AccountId
        WHERE a.CountyId = ?
          AND t.DateCoded IS NOT NULL
    """, county_id)
    currently_datecoded_ids = {r[0].strip() for r in cursor.fetchall()}

    expired_account_numbers = [
        acct for acct in currently_datecoded_ids if acct not in csv_pids_set
    ]

    cursor.execute("""
        SELECT a.AccountNumber
        FROM PTAX_AofA_Test t
        JOIN ptax_account_test a ON a.AccountId = t.AccountId
        WHERE a.CountyId = ?
    """, county_id)
    existing_aofa_accounts = {r[0].strip() for r in cursor.fetchall()}

    updated_account_numbers  = [p for p in matched_pids if p in existing_aofa_accounts]
    inserted_account_numbers = [p for p in matched_pids if p not in existing_aofa_accounts]

    datecoded_updated_count = len(updated_account_numbers)
    datecoded_end_count     = len(expired_account_numbers)
    inserted_count          = len(inserted_account_numbers)

    log.info(
        f"   SP preview → "
        f"UPDATE(datecoded): {datecoded_updated_count} | "
        f"EXPIRE(datecodedEnd): {datecoded_end_count} | "
        f"INSERT(new): {inserted_count}"
    )

    return {
        "total_accounts":           total_accounts,
        "matched_pids":             matched_pids,
        "unmatched_pids":           unmatched_pids,
        "datecoded_updated_count":  datecoded_updated_count,
        "datecoded_end_count":      datecoded_end_count,
        "inserted_count":           inserted_count,
        "updated_account_numbers":  updated_account_numbers,
        "expired_account_numbers":  expired_account_numbers,
        "inserted_account_numbers": inserted_account_numbers,
    }


# ─────────────────────────────────────────────────────────────────
#  DB UPDATE  (shared — handles both .csv and .xlsx)
# ─────────────────────────────────────────────────────────────────
def update_database(file_path: str, county_code: str) -> dict:
    county = COUNTY_MAP.get(county_code)
    if not county:
        log.warning(f"❌ No mapping for county_code='{county_code}'")
        return _empty_stats()

    log.info(f"🚀 DB update starting for {county}  [{now_ist_str()}]")

    conn   = pyodbc.connect(CONN_STR)
    cursor = conn.cursor()
    cursor.fast_executemany = True

    cursor.execute(
        "SELECT CountyId FROM ptax_County_Test WHERE CountyName = ?", county
    )
    row = cursor.fetchone()
    if not row:
        log.warning(f"❌ County '{county}' not found in ptax_County_Test")
        conn.close()
        return _empty_stats()
    county_id = row[0]

    cursor.execute("DELETE FROM PTAX_AofA_Staging WHERE CountyName = ?", county)

    property_ids: list[tuple] = []
    csv_pids:     list[str]   = []

    suffix = Path(file_path).suffix.lower()
    if suffix == ".xlsx":
        try:
            import openpyxl
            wb      = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
            ws      = wb.active
            headers = [
                str(c.value).strip() if c.value else ""
                for c in next(ws.iter_rows(min_row=1, max_row=1))
            ]
            for ws_row in ws.iter_rows(min_row=2, values_only=True):
                row_dict = dict(zip(headers, ws_row))
                pid = get_property_id(row_dict)
                if pid:
                    property_ids.append((pid, county))
                    csv_pids.append(pid)
            wb.close()
        except ImportError:
            log.error("openpyxl not installed — run: pip install openpyxl")
            conn.close()
            return _empty_stats()
    else:
        with open(file_path, encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                pid = get_property_id(row)
                if pid:
                    property_ids.append((pid, county))
                    csv_pids.append(pid)

    log.info(f"📊 {county}: {len(csv_pids)} property IDs found in file")

    if not property_ids:
        log.warning(f"⚠️  No property IDs found for {county}")
        conn.close()
        return _empty_stats()

    cursor.executemany(
        "INSERT INTO PTAX_AofA_Staging (PropertyId, CountyName) VALUES (?, ?)",
        property_ids,
    )
    conn.commit()

    stats = collect_pre_sp_stats(cursor, county, county_id, csv_pids)

    cursor.execute("EXEC USP_Update_DateCoded_Fast @CountyName = ?", county)
    conn.commit()

    log.info(f"✅ SP executed for {county}  [{now_ist_str()}]")
    log.info(f"   Total accounts : {stats['total_accounts']}")
    log.info(
        f"   DateCoded ↑    : {stats['datecoded_updated_count']} updated  |  "
        f"DateCodedEnd ↑ : {stats['datecoded_end_count']} expired  |  "
        f"Inserted ✨    : {stats['inserted_count']} new"
    )
    log.info(
        f"   Status         : {len(stats['matched_pids'])} Success  |  "
        f"{len(stats['unmatched_pids'])} Failure"
    )

    cursor.close()
    conn.close()

    return {
        "total_accounts":           stats["total_accounts"],
        "total_csv":                len(csv_pids),
        "datecoded_updated_count":  stats["datecoded_updated_count"],
        "datecoded_end_count":      stats["datecoded_end_count"],
        "inserted_count":           stats["inserted_count"],
        "success_count":            len(stats["matched_pids"]),
        "failure_count":            len(stats["unmatched_pids"]),
        "success_pids":             stats["matched_pids"],
        "failure_pids":             stats["unmatched_pids"],
        "updated_pids":             stats["updated_account_numbers"],
        "expired_pids":             stats["expired_account_numbers"],
        "inserted_pids":            stats["inserted_account_numbers"],
    }


# ─────────────────────────────────────────────────────────────────
#  STEP 1A – HTTP DOWNLOAD  (returns saved file path or raises)
# ─────────────────────────────────────────────────────────────────
def _http_download(county: dict) -> str | None:
    name        = county["name"]
    county_code = county["county_code"]
    base_url    = county["base_url"]
    agent_codes = county["agent_codes"]
    year        = county["year"]

    session = requests.Session()
    session.proxies.update(PROXIES)
    session.headers.update(HEADERS)

    folder  = os.path.join(BASE_PATH, county_code)
    os.makedirs(folder, exist_ok=True)

    ts_str  = now_ist_file_stamp()
    file    = os.path.join(folder, f"{county_code}_{year}_{ts_str}.csv")
    dl_url  = base_url.rstrip("/") + "/search/SearchResultDownload"
    keyword = f"AgentId:{agent_codes} Year:{year}"

    all_rows = []
    page     = 1

    while True:
        params   = {"keywords": keyword, "pageNumber": page, "pageSize": 1000}
        last_exc = None
        rows     = None

        for attempt in range(1, 4):
            try:
                r = session.get(dl_url, params=params, timeout=60)
                r.raise_for_status()
                rows = list(csv.DictReader(io.StringIO(r.text)))
                break
            except Exception as e:
                last_exc = e
                wait = 2 ** attempt
                log.warning(
                    f"⚠️  [{name}] fetch attempt {attempt}/3 failed ({e}) "
                    f"— retrying in {wait}s"
                )
                time.sleep(wait)

        if rows is None:
            log.error(f"❌ [{name}] fetch gave up after 3 attempts: {last_exc}")
            raise last_exc

        if not rows:
            break
        all_rows.extend(rows)
        if len(rows) < 1000:
            break
        page += 1

    if not all_rows:
        log.warning(f"⚠️  [{name}] No rows returned from server")
        return None

    with open(file, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=all_rows[0].keys())
        writer.writeheader()
        writer.writerows(all_rows)

    log.info(
        f"✅ [{name}] CSV saved → {file}  "
        f"({len(all_rows)} rows)  [{now_ist_str()}]"
    )
    return file


# ─────────────────────────────────────────────────────────────────
#  STEP 1B – PLAYWRIGHT DOWNLOAD  (returns saved file path or None)
#            Fresh sync_playwright() per county — fully isolated
# ─────────────────────────────────────────────────────────────────
def _playwright_download(county: dict) -> str | None:
    name        = county["name"]
    county_code = county["county_code"]

    folder    = os.path.join(BASE_PATH, county_code)
    os.makedirs(folder, exist_ok=True)

    ts_str    = now_ist_file_stamp()
    save_path = os.path.join(folder, f"{county_code}_{ts_str}.xlsx")

    log.info(f"🌐 [{name}] Starting Playwright download …")

    # Each county: own Playwright instance → own browser → own context
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=False)
        context = browser.new_context(accept_downloads=True)
        page    = context.new_page()

        try:
            # 1. Navigate to sign-in
            log.info(f"[{name}] Navigating to {county['url']}")
            page.goto(county["url"])
            time.sleep(5)

            # 2. Enter email
            log.info(f"[{name}] Entering email …")
            page.get_by_role("textbox", name="Email Address").fill(county["username"])
            time.sleep(5)
            page.get_by_role("button", name="Next").click()
            time.sleep(5)

            # 3. Enter password
            log.info(f"[{name}] Entering password …")
            page.get_by_role("textbox", name="Password").fill(county["password"])
            time.sleep(5)
            page.get_by_role("button", name="Login").click()
            time.sleep(5)

            # 4. My Properties
            log.info(f"[{name}] Opening 'My Properties' …")
            page.get_by_text("My Properties", exact=True).click()
            time.sleep(5)

            # 5. First Agent Status → All
            log.info(f"[{name}] Setting first Agent Status filter to All …")
            page.get_by_role("combobox", name="Agent Status").first.click()
            time.sleep(5)
            page.get_by_role("option", name="All").click()
            time.sleep(5)

            # 6. Second Agent Status → All
            log.info(f"[{name}] Setting second Agent Status filter to All …")
            page.get_by_role("combobox", name="Agent Status All").nth(1).click()
            time.sleep(5)
            page.get_by_role("option", name="All").click()
            time.sleep(5)

            # 7. Mass Download
            log.info(f"[{name}] Clicking 'Mass Download' …")
            page.get_by_role("button", name="Mass Download").click()
            time.sleep(5)

            log.info(f"[{name}] Selecting 'Download All Item(s) in Excel' …")
            page.get_by_text("Download All Item(s) in Excel").click()
            time.sleep(5)

            # 8. Download Log
            log.info(f"[{name}] Opening Download Log …")
            page.get_by_role("link", name="Download Log").click()
            time.sleep(5)

            # 9. Save file
            log.info(f"[{name}] Saving file → {save_path}")
            with page.expect_download() as dl_info:
                page.get_by_role("link", name="File").first.click()

            dl_info.value.save_as(save_path)
            log.info(f"✅ [{name}] XLSX saved → {save_path}  [{now_ist_str()}]")
            return save_path

        except Exception as exc:
            log.error(f"❌ [{name}] Playwright step failed: {exc}")
            return None

        finally:
            context.close()
            browser.close()


# ─────────────────────────────────────────────────────────────────
#  PROCESS ONE COUNTY
#  Strict sequence: download → DB update → sidecar
#  Nothing from county N leaks into county N+1
# ─────────────────────────────────────────────────────────────────
def process_county(county: dict):
    county_code = county["county_code"]
    name        = county.get("name", county_code)
    strategy    = county["strategy"]

    log.info(f"┌─ START [{name}]  strategy={strategy}  {now_ist_str()}")

    # ── STEP 1: Download ──────────────────────────────────────────
    saved_path = None
    try:
        if strategy == "http":
            saved_path = _http_download(county)
        elif strategy == "playwright":
            saved_path = _playwright_download(county)
        else:
            log.error(f"Unknown strategy '{strategy}' for {name}")
    except Exception as e:
        log.error(f"❌ [{name}] Download exception: {e}")

    if not saved_path:
        folder     = os.path.join(BASE_PATH, county_code)
        os.makedirs(folder, exist_ok=True)
        dummy_path = os.path.join(folder, f"{county_code}_{now_ist_file_stamp()}.log")
        write_sidecar(dummy_path, _build_sidecar("error", _empty_stats(), error="Download failed"))
        log.info(f"└─ END   [{name}]  ❌ download failed  {now_ist_str()}")
        return

    # ── STEP 2: DB update ─────────────────────────────────────────
    db = _empty_stats()
    try:
        db = update_database(saved_path, county_code)
    except Exception as e:
        log.error(f"❌ [{name}] DB update exception: {e}")
        write_sidecar(saved_path, _build_sidecar("error", _empty_stats(), error=str(e)))
        log.info(f"└─ END   [{name}]  ❌ DB update failed  {now_ist_str()}")
        return

    # ── STEP 3: Write sidecar ─────────────────────────────────────
    write_sidecar(saved_path, _build_sidecar("success", db))

    log.info(f"└─ END   [{name}]  ✅ complete  {now_ist_str()}")


# ─────────────────────────────────────────────────────────────────
#  MAIN LOOP
# ─────────────────────────────────────────────────────────────────
def run():
    total = len(COUNTY_QUEUE)
    log.info("═" * 60)
    log.info(f"▶  Run started at {now_ist_str()} IST  ({total} counties)")
    log.info("═" * 60)

    for i, county in enumerate(COUNTY_QUEUE, start=1):
        name = county.get("name", county["county_code"])
        log.info(f"  County {i}/{total}: {name}  [{county['strategy'].upper()}]")
        process_county(county)
        log.info("")   # blank separator between counties

    log.info("═" * 60)
    log.info(f"✔  Run finished at {now_ist_str()} IST")
    log.info("═" * 60)


if __name__ == "__main__":
    while True:
        run()
        time.sleep(INTERVAL_MINUTES * 240)
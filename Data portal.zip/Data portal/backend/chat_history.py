import json
import os
import uuid
from datetime import datetime

CHAT_FILE = "chats.json"
MAX_CHATS = 5


# ─── Load all chats from file ───
def load_chats() -> dict:
    if not os.path.exists(CHAT_FILE):
        return {}
    with open(CHAT_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


# ─── Save all chats to file ───
def save_chats(chats: dict):
    with open(CHAT_FILE, "w", encoding="utf-8") as f:
        json.dump(chats, f, indent=2, ensure_ascii=False)


# ─── Create a new chat session ───
def create_chat(title: str = "New Chat") -> dict:
    chats = load_chats()

    # Enforce MAX_CHATS: remove oldest if at limit
    if len(chats) >= MAX_CHATS:
        oldest_id = sorted(chats, key=lambda k: chats[k]["created_at"])[0]
        del chats[oldest_id]

    chat_id = str(uuid.uuid4())
    chats[chat_id] = {
        "id": chat_id,
        "title": title,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "messages": []
    }

    save_chats(chats)
    return chats[chat_id]


# ─── Get a single chat by ID ───
def get_chat(chat_id: str) -> dict | None:
    chats = load_chats()
    return chats.get(chat_id)


# ─── Get all chats (sorted newest first) ───
def get_all_chats() -> list:
    chats = load_chats()
    return sorted(chats.values(), key=lambda c: c["updated_at"], reverse=True)


# ─── Append a message to a chat ───
def append_message(chat_id: str, role: str, content: str) -> dict | None:
    chats = load_chats()
    if chat_id not in chats:
        return None

    message = {
        "id": str(uuid.uuid4()),
        "role": role,          # "user" or "assistant"
        "content": content,
        "time": datetime.now().strftime("%I:%M %p")
    }

    chats[chat_id]["messages"].append(message)
    chats[chat_id]["updated_at"] = datetime.now().isoformat()

    # Auto-title from first user message
    if role == "user" and chats[chat_id]["title"] == "New Chat":
        chats[chat_id]["title"] = content[:40] + ("…" if len(content) > 40 else "")

    save_chats(chats)
    return message


# ─── Delete a chat ───
def delete_chat(chat_id: str) -> bool:
    chats = load_chats()
    if chat_id not in chats:
        return False
    del chats[chat_id]
    save_chats(chats)
    return True


# ─── Rename a chat ───
def rename_chat(chat_id: str, new_title: str) -> dict | None:
    chats = load_chats()
    if chat_id not in chats:
        return None
    chats[chat_id]["title"] = new_title
    chats[chat_id]["updated_at"] = datetime.now().isoformat()
    save_chats(chats)
    return chats[chat_id]
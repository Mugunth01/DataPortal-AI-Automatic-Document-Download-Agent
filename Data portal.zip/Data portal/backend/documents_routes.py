"""
documents_routes.py  ─  Add these routes to main.py
─────────────────────────────────────────────────────
POST /documents/upload
  • Accepts a CSV or XLSX file + county name
  • Extracts property IDs (same logic as autodownload.py)
  • Inserts into PTAX_AofA_Staging
  • Calls USP_Update_DateCoded_Fast
  • Returns full stats (mirrors autodownload.py sidecar format)

GET /documents/status/{upload_id}
  • Returns status of a background upload (future use)

─────────────────────────────────────────────────────
PASTE these imports at the top of main.py (if not already present):

  import csv, io, uuid
  from fastapi import UploadFile, File, Form

Then paste the two route handlers below into main.py.
─────────────────────────────────────────────────────
"""

# ── Add these imports to main.py if not already there ────────────
# import csv
# import io
# from fastapi import UploadFile, File, Form

# ─────────────────────────────────────────────────────────────────
#  IN-MEMORY STATUS STORE  (keyed by upload_id)
#  Replace with a DB table or Redis for production.
# ─────────────────────────────────────────────────────────────────
_upload_status: dict = {}   # upload_id → result dict


# ─────────────────────────────────────────────────────────────────
#  HELPERS  (same logic as autodownload.py)
# ─────────────────────────────────────────────────────────────────
def _get_property_id(row: dict) -> str | None:
    """Extract the property/account ID column from a CSV row."""
    for key in row:
        k = key.replace("\ufeff", "").lower().replace(" ", "").replace("_", "")
        if "propertyid" in k or "accountnumber" in k or "account" in k:
            val = row[key].strip()
            if val:
                return val
    return None


def _extract_pids_from_csv_bytes(content: bytes) -> list[str]:
    """Parse raw CSV bytes → list of property IDs."""
    text   = content.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    pids   = []
    for row in reader:
        pid = _get_property_id(row)
        if pid:
            pids.append(pid)
    return pids


def _extract_pids_from_xlsx_bytes(content: bytes) -> list[str]:
    """Parse raw XLSX bytes → list of property IDs using openpyxl."""
    import openpyxl, io as _io
    wb = openpyxl.load_workbook(_io.BytesIO(content), read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(h).strip() if h is not None else "" for h in rows[0]]
    pids = []
    for row in rows[1:]:
        row_dict = dict(zip(headers, [str(c).strip() if c is not None else "" for c in row]))
        pid = _get_property_id(row_dict)
        if pid:
            pids.append(pid)
    return pids


def _run_db_update_for_upload(county: str, csv_pids: list[str]) -> dict:
    """
    Mirrors autodownload.py → collect_pre_sp_stats + SP call.
    Returns the same sidecar-style dict.
    """
    conn   = get_db()
    cursor = conn.cursor()
    cursor.fast_executemany = True

    # ── Get county id ──────────────────────────────────────────
    cursor.execute(
        "SELECT CountyId FROM ptax_County_Test WHERE CountyName = ?", county
    )
    row = cursor.fetchone()
    if not row:
        conn.close()
        raise ValueError(f"County '{county}' not found in ptax_County_Test")
    county_id = row[0]

    # ── Total accounts for KPI ─────────────────────────────────
    cursor.execute(
        "SELECT COUNT(*) FROM ptax_account_test WHERE CountyId = ?", county_id
    )
    total_accounts = cursor.fetchone()[0]

    # ── Clear staging, then bulk-insert ───────────────────────
    cursor.execute("DELETE FROM PTAX_AofA_Staging WHERE CountyName = ?", county)
    if csv_pids:
        cursor.executemany(
            "INSERT INTO PTAX_AofA_Staging (PropertyId, CountyName) VALUES (?, ?)",
            [(pid, county) for pid in csv_pids],
        )
    conn.commit()

    # ── All DB account numbers for this county ─────────────────
    cursor.execute(
        "SELECT AccountId, AccountNumber FROM ptax_account_test WHERE CountyId = ?",
        county_id,
    )
    db_rows        = cursor.fetchall()
    db_account_map = {r[1].strip(): r[0] for r in db_rows}
    db_acct_set    = set(db_account_map.keys())
    csv_pids_set   = set(csv_pids)

    matched_pids   = [p for p in csv_pids if p in db_acct_set]
    unmatched_pids = [p for p in csv_pids if p not in db_acct_set]

    # ── EXPIRE block ───────────────────────────────────────────
    cursor.execute("""
        SELECT a.AccountNumber
        FROM PTAX_AofA_Test t
        JOIN ptax_account_test a ON a.AccountId = t.AccountId
        WHERE a.CountyId = ? AND t.DateCoded IS NOT NULL
    """, county_id)
    currently_coded     = {r[0].strip() for r in cursor.fetchall()}
    expired_pids        = [a for a in currently_coded if a not in csv_pids_set]
    datecoded_end_count = len(expired_pids)

    # ── UPDATE block ───────────────────────────────────────────
    cursor.execute("""
        SELECT a.AccountNumber
        FROM PTAX_AofA_Test t
        JOIN ptax_account_test a ON a.AccountId = t.AccountId
        WHERE a.CountyId = ?
    """, county_id)
    existing_aofa  = {r[0].strip() for r in cursor.fetchall()}
    updated_pids   = [p for p in matched_pids if p in existing_aofa]
    inserted_pids  = [p for p in matched_pids if p not in existing_aofa]

    # ── Call stored procedure ──────────────────────────────────
    cursor.execute("EXEC USP_Update_DateCoded_Fast @CountyName = ?", county)
    conn.commit()
    cursor.close()
    conn.close()

    return {
        "totalAccounts":     total_accounts,
        "totalCsv":          len(csv_pids),
        "datecodedUpdated":  len(updated_pids),
        "datecodedEnd":      datecoded_end_count,
        "insertedCount":     len(inserted_pids),
        "successCount":      len(matched_pids),
        "failureCount":      len(unmatched_pids),
        "successPids":       matched_pids[:500],
        "failurePids":       unmatched_pids[:500],
        "updatedPids":       updated_pids[:500],
        "expiredPids":       expired_pids[:500],
        "insertedPids":      inserted_pids[:500],
    }


# ─────────────────────────────────────────────────────────────────
#  ROUTE:  POST /documents/upload
# ─────────────────────────────────────────────────────────────────
@app.post("/documents/upload")
async def upload_document(
    file:   UploadFile = File(...),
    county: str        = Form("Bell"),
):
    """
    1. Read uploaded CSV or XLSX
    2. Extract property IDs
    3. Run DB update (same as autodownload.py)
    4. Return stats
    """
    upload_id = str(uuid.uuid4())
    filename  = file.filename or "upload.csv"
    ext       = filename.rsplit(".", 1)[-1].lower()

    if ext not in ("csv", "xlsx", "xls"):
        raise HTTPException(status_code=400, detail="Only CSV or Excel files are supported.")

    content = await file.read()

    # ── Extract property IDs ───────────────────────────────────
    try:
        if ext == "csv":
            csv_pids = _extract_pids_from_csv_bytes(content)
        else:
            csv_pids = _extract_pids_from_xlsx_bytes(content)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Could not parse file: {e}")

    if not csv_pids:
        raise HTTPException(
            status_code=422,
            detail="No property IDs found. Make sure the file has a column named 'PropertyId' or 'AccountNumber'.",
        )

    # ── Run DB update ──────────────────────────────────────────
    try:
        stats = _run_db_update_for_upload(county, csv_pids)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        log.error(f"DB update failed for uploaded file: {e}")
        raise HTTPException(status_code=500, detail=f"DB update failed: {e}")

    # ── IST timestamp ──────────────────────────────────────────
    ist_now  = now_ist()
    result   = {
        "id":       upload_id,
        "filename": filename,
        "county":   county,
        "date":     format_ist_datetime(ist_now),
        "time":     format_ist_time(ist_now),
        "status":   "success",
        **stats,
    }

    _upload_status[upload_id] = result
    return result


# ─────────────────────────────────────────────────────────────────
#  ROUTE:  GET /documents/status/{upload_id}
# ─────────────────────────────────────────────────────────────────
@app.get("/documents/status/{upload_id}")
def get_upload_status(upload_id: str):
    """Return the result of a previous upload by ID."""
    result = _upload_status.get(upload_id)
    if not result:
        raise HTTPException(status_code=404, detail="Upload ID not found")
    return result
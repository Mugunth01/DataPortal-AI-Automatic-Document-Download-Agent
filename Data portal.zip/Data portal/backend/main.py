"""
main.py  ─  FastAPI backend for DataPortal AI
----------------------------------------------------
ALL times and dates are in IST (Asia/Kolkata, UTC+5:30).
- parse_date_filter  → compares against IST date
- download-logs      → mtime converted to IST
- db-logs            → mtime converted to IST
- timestamps sent to frontend are already IST strings
"""

import re
import uuid
import pyodbc
import logging
import requests
from datetime import datetime, date, timedelta, timezone, time as dt_time
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo          # Python 3.9+

from fastapi import FastAPI, Query, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from fastapi import UploadFile, File, Form
import csv, io
from chat_history import (
    create_chat, get_chat, get_all_chats,
    append_message, delete_chat, rename_chat
)

log = logging.getLogger("uvicorn.error")

# ─────────────────────────────────────────────────────────────────
#  IST TIMEZONE
# ─────────────────────────────────────────────────────────────────
IST = ZoneInfo("Asia/Kolkata")

def now_ist() -> datetime:
    """Return current datetime in IST."""
    return datetime.now(tz=IST)

def today_ist() -> date:
    """Return today's date in IST."""
    return now_ist().date()

def mtime_ist(path: Path) -> datetime:
    """Convert a file's mtime (local/UTC) to IST datetime."""
    # stat().st_mtime is a POSIX timestamp (UTC-based)
    return datetime.fromtimestamp(path.stat().st_mtime, tz=IST)

def format_ist_time(dt: datetime) -> str:
    """HH:MM in IST."""
    return dt.strftime("%H:%M")

def format_ist_datetime(dt: datetime) -> str:
    """ISO date string YYYY-MM-DD in IST."""
    return dt.strftime("%Y-%m-%d")


app = FastAPI(title="DataPortal API")

# ─────────────────────────────────────────────────────────────────
#  NGROK URL REFERENCE
#  BACKEND  ngrok URL (this server) → used in frontend API const:
#    https://61ad-111-93-110-218.ngrok-free.app
#
#  FRONTEND ngrok URL → listed below in CORS so browser requests
#  from the frontend tunnel are accepted by this backend:
#    https://3d5b-111-93-110-218.ngrok-free.app
# ─────────────────────────────────────────────────────────────────
FRONTEND_ORIGINS = [
    "http://localhost:3000",                        # local React dev
    "http://127.0.0.1:3000",
    "https://34c5-47-247-176-98.ngrok-free.app",  # ← frontend ngrok URL
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────────────
BASE_PATH = r"\\sanserver\PFBA Fileserver\Software Engineering\Taxroll_Data\Team Details\Backup\Mugunthan\hackthon"

CONN_STR = (
    "DRIVER={ODBC Driver 13 for SQL Server};"
    "SERVER=taxrollstage-db;"
    "DATABASE=TaxrollStaging;"
    "Trusted_Connection=yes;"
)

COUNTY_MAP = {
    # HTTP counties
    "bellcad":       "Bell",
    "starrcad":      "Starr",
    "browncad":      "Brown",
    "brookscad":     "Brooks",
    "brewstercotad": "Brewster",
    # Playwright counties
    "elliscad":      "Ellis",
    "hidalgoad":     "Hidalgo",
    "prad":          "Potter-Randall",
    "rockwallcad":   "Rockwall",
    "webbcad":       "Webb",
    "dentoncad":     "Denton",
    "mcad-tx":       "MCAD",
    "travis":        "Travis",
}

COUNTIES_CONFIG = [
    ("https://esearch.bellcad.org/",       "581950", "2026"),
    ("https://esearch.brewstercotad.org/", "28350",  "2026"),
    ("https://esearch.brookscad.org/",     "135069", "2025"),
    ("https://esearch.brown-cad.org/",     "89983",  "2026"),
    ("https://esearch.starrcad.org/",      "103283", "2025"),
]

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "gemma4:e2b"

TABLES = [
    "PTAX_AofA_Test",
    "ptax_account_Test",
    "ptax_County_Test",
    "PTAX_AofAAutomation_DateCodedHistory_Test",
]
JOIN_RELATIONS = [
    ("PTAX_AofA_Test", "ptax_account_Test",
     "PTAX_AofA_Test.AccountId = ptax_account_Test.AccountId"),
    ("ptax_account_Test", "ptax_County_Test",
     "ptax_account_Test.CountyId = ptax_County_Test.CountyId"),
    ("PTAX_AofA_Test", "PTAX_AofAAutomation_DateCodedHistory_Test",
     "PTAX_AofA_Test.AccountId = PTAX_AofAAutomation_DateCodedHistory_Test.AccountId"),
]


# ─────────────────────────────────────────────────────────────────
#  REQUEST MODELS
# ─────────────────────────────────────────────────────────────────
class AskRequest(BaseModel):
    question: str
    chat_id: Optional[str] = None

class NewChatRequest(BaseModel):
    title: str = "New Chat"

class RenameRequest(BaseModel):
    title: str

class TriggerRequest(BaseModel):
    county: str


# ─────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────
def get_db():
    return pyodbc.connect(CONN_STR)

def county_name_from_url(url: str) -> str:
    host = re.sub(r"https?://", "", url).rstrip("/")
    host = re.sub(r"^esearch\.", "", host)
    host = re.sub(r"\.(org|com|net|info)$", "", host)
    return host.replace("-", "")

def parse_date_filter(df: str):
    """
    Returns (start_date, end_date) both as date objects in IST.
    Accepts: "today", "yesterday", or "YYYY-MM-DD" (specific date).
    """
    today_ist_date = today_ist()

    if df == "today":
        return today_ist_date, today_ist_date

    if df == "yesterday":
        d = today_ist_date - timedelta(days=1)
        return d, d

    # Specific calendar date from frontend picker
    try:
        d = date.fromisoformat(df)
        return d, d
    except ValueError:
        # Fallback to today
        return today_ist_date, today_ist_date

def read_sidecar(csv_path: str) -> dict:
    import json
    try:
        with open(csv_path + ".log.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


# ─────────────────────────────────────────────────────────────────
#  AUTOMATION  ─  DOWNLOAD LOGS
# ─────────────────────────────────────────────────────────────────
@app.get("/automation/download-logs")
def get_download_logs(date_filter: str = Query("today")):
    start, end = parse_date_filter(date_filter)
    results = []
    base = Path(BASE_PATH)
    if not base.exists():
        return []

    for county_dir in base.iterdir():
        if not county_dir.is_dir():
            continue
        county_code = county_dir.name
        county_name = COUNTY_MAP.get(county_code, county_code.title())

        for csv_file in sorted(
                list(county_dir.glob("*.csv")) +
                list(county_dir.glob("*.xlsx")) +
                list(county_dir.glob("*.log")),
                reverse=True
        ):
            # Convert mtime to IST
            mtime_in_ist = mtime_ist(csv_file)
            file_date    = mtime_in_ist.date()   # IST date

            if not (start <= file_date <= end):
                continue

            sc = read_sidecar(str(csv_file))
            results.append({
                "id":          str(uuid.uuid4()),
                "county":      county_name,
                "county_code": county_code,
                "time":        format_ist_time(mtime_in_ist),       # HH:MM IST
                "date":        format_ist_datetime(mtime_in_ist),   # YYYY-MM-DD IST
                "filename":    csv_file.name,
                "filepath":    str(csv_file),
                "fileSize":    f"{round(csv_file.stat().st_size / (1024 * 1024), 2)} MB",
                "totalCsv":    sc.get("totalCsv", 0),
                "matched":     sc.get("successCount", 0),
                "successPids": sc.get("successPids", []),
                "failPids":    sc.get("failurePids", []),
                "status":      sc.get("status", "error"),
            })

    results.sort(key=lambda x: (x["date"], x["time"]), reverse=True)
    return results


@app.get("/automation/debug-files")
def debug_files():
    base = Path(BASE_PATH)
    if not base.exists():
        return {"error": f"BASE_PATH does not exist: {BASE_PATH}"}
    result = []
    for county_dir in base.iterdir():
        if not county_dir.is_dir():
            continue
        files = []
        for f in county_dir.iterdir():
            mtime = mtime_ist(f)
            files.append({
                "name": f.name,
                "mtime_ist": format_ist_datetime(mtime),
                "time_ist": format_ist_time(mtime),
                "has_sidecar": Path(str(f) + ".log.json").exists(),
            })
        result.append({"county": county_dir.name, "files": files})
    return result

# ─────────────────────────────────────────────────────────────────
#  AUTOMATION  ─  DB UPDATE LOGS
# ─────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────
#  AUTOMATION  ─  DB UPDATE LOGS
# ─────────────────────────────────────────────────────────────────
@app.get("/automation/db-logs")
def get_db_logs(date_filter: str = Query("today")):
    """
    Reads sidecar JSON files. All time comparisons are in IST.
    Returns SP-accurate stats per county per CSV run.
    """
    start, end = parse_date_filter(date_filter)
    results = []
    base = Path(BASE_PATH)
    if not base.exists():
        return []

    for county_dir in base.iterdir():
        if not county_dir.is_dir():
            continue
        county_code = county_dir.name
        county_name = COUNTY_MAP.get(county_code, county_code.title())

        all_files = sorted(
            list(county_dir.glob("*.csv")) +
            list(county_dir.glob("*.xlsx")),
            reverse=True
        )

        for data_file in all_files:
            mtime_in_ist = mtime_ist(data_file)
            file_date    = mtime_in_ist.date()

            if not (start <= file_date <= end):
                continue

            sc = read_sidecar(str(data_file))
            if not sc:
                continue   # not yet processed

            results.append({
                "id":               str(uuid.uuid4()),
                "county":           county_name,
                "time":             format_ist_time(mtime_in_ist),
                "date":             format_ist_datetime(mtime_in_ist),
                "totalAccounts":    sc.get("totalAccounts", 0),
                "datecodedUpdated": sc.get("datecodedUpdated", 0),
                "datecodedEnd":     sc.get("datecodedEndCount", 0),
                "insertedCount":    sc.get("insertedCount", 0),
                "successCount":     sc.get("successCount", 0),
                "failureCount":     sc.get("failureCount", 0),
                "status":           sc.get("status", "error"),
                "successPids":      sc.get("successPids", []),
                "failurePids":      sc.get("failurePids", []),
                "updatedPids":      sc.get("updatedPids", []),
                "expiredPids":      sc.get("expiredPids", []),
                "insertedPids":     sc.get("insertedPids", []),
            })

    results.sort(key=lambda x: (x["date"], x["time"]), reverse=True)
    return results
# ─────────────────────────────────────────────────────────────────
#  AUTOMATION  ─  DOWNLOAD FILE
# ─────────────────────────────────────────────────────────────────
@app.get("/automation/download-file")
def download_file(filepath: str = Query(...)):
    p    = Path(filepath).resolve()
    base = Path(BASE_PATH).resolve()
    try:
        p.relative_to(base)
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied")
    if not p.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(path=str(p), media_type="text/csv", filename=p.name)


# ─────────────────────────────────────────────────────────────────
#  AUTOMATION  ─  TRIGGER
# ─────────────────────────────────────────────────────────────────
@app.post("/automation/trigger")
def trigger_county(req: TriggerRequest, background_tasks: BackgroundTasks):
    target = None
    for url, agent_codes, year in COUNTIES_CONFIG:
        code   = county_name_from_url(url)
        mapped = COUNTY_MAP.get(code, "")
        if mapped.lower() == req.county.lower():
            target = (url, agent_codes, year)
            break
    if not target:
        raise HTTPException(status_code=404, detail=f"County '{req.county}' not found")
    try:
        from autodownload import download_county
        background_tasks.add_task(download_county, *target)
        return {"status": "ok", "message": f"{req.county} download started in background"}
    except ImportError:
        raise HTTPException(status_code=500, detail="autodownload.py not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────
#  OLLAMA / SQL HELPERS
# ─────────────────────────────────────────────────────────────────
def get_full_schema():
    conn = get_db(); cursor = conn.cursor()
    schema = {}
    for table in TABLES:
        cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='{table}'")
        schema[table] = [r[0] for r in cursor.fetchall()]
    conn.close()
    return schema

def detect_limit(question: str) -> Optional[int]:
    q = question.lower()
    for word in q.split():
        if word.isdigit(): return int(word)
    if any(k in q for k in ["top", "first", "sample", "few"]): return 10
    return None

def generate_sql(question: str, history: list) -> str:
    schema = get_full_schema()
    joins_text = "\n".join([f"  {l} JOIN {r} ON {c}" for l, r, c in JOIN_RELATIONS])
    history_text = ""
    if history:
        history_text = "\n\nConversation so far:\n"
        for msg in history[-6:]:
            role = "User" if msg["role"] == "user" else "Assistant"
            history_text += f"{role}: {msg['content']}\n"
    prompt = f"""You are an expert SQL Server assistant.
Tables: {schema}
Relationships:\n{joins_text}
Rules: Use ONLY listed tables. Correct JOINs. No SELECT *. Explicit columns.
COUNT(*) AS total_count when counting. DISTINCT when needed.
Only TOP if asked. Return ONLY SQL, no markdown.
{history_text}
Question: {question}"""
    try:
        r = requests.post(OLLAMA_URL, json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False}, timeout=60)
        return r.json().get("response", "").strip()
    except Exception as e:
        raise RuntimeError(f"Ollama unavailable: {e}")

def fix_sql(sql: str, question: str) -> str:
    sql = re.sub(r"TOP\s+\d+\s*$", "", sql, flags=re.IGNORECASE)
    sql = re.sub(r"```sql|```", "", sql, flags=re.IGNORECASE).strip()
    limit = detect_limit(question)
    if limit and "top" not in sql.lower():
        sql = sql.replace("SELECT", f"SELECT TOP {limit}", 1)
    return sql.strip()

def execute_sql(sql: str) -> list:
    conn = get_db(); cursor = conn.cursor()
    cursor.execute(sql)
    columns = [col[0] for col in cursor.description]
    data = [dict(zip(columns, row)) for row in cursor.fetchall()]
    conn.close()
    return data

def format_response(data: list, question: str = "") -> dict:
    if not data: return {"answer": "No matching data found."}
    rows, cols = len(data), len(data[0]); q = question.lower()
    if rows == 1 and cols == 1: return {"answer": f"The result is {list(data[0].values())[0]}."}
    if cols == 1:
        col = list(data[0].keys())[0]; values = [str(r[col]) for r in data]
        if "comma" in q: return {"answer": f"{col} values:", "text": ", ".join(values)}
        return {"answer": f"Here are the {col} values:", "list": values}
    if cols <= 3 and rows <= 5:
        lines = [", ".join([f"{k}: {v}" for k, v in r.items()]) for r in data]
        return {"answer": "Here are the results:", "list": lines}
    return {"answer": f"Showing {min(rows, 20)} of {rows} records.", "data": data[:20]}


# ─────────────────────────────────────────────────────────────────
#  CHAT ENDPOINTS
# ─────────────────────────────────────────────────────────────────
@app.get("/chats")
def list_chats():
    return [{"id": c["id"], "title": c["title"], "updated_at": c.get("updated_at", "")} for c in get_all_chats()]

@app.post("/chats")
def new_chat(req: NewChatRequest):
    return create_chat(req.title)

@app.get("/chats/{chat_id}")
def load_chat(chat_id: str):
    chat = get_chat(chat_id)
    if not chat: raise HTTPException(status_code=404, detail="Chat not found")
    return chat

@app.delete("/chats/{chat_id}")
def remove_chat(chat_id: str):
    return {"success": delete_chat(chat_id)}

@app.patch("/chats/{chat_id}/rename")
def rename_chat_ep(chat_id: str, req: RenameRequest):
    return rename_chat(chat_id, req.title)


# ─────────────────────────────────────────────────────────────────
#  ASK
# ─────────────────────────────────────────────────────────────────
@app.post("/ask")
def ask(req: AskRequest):
    question = req.question.strip()
    chat_id  = req.chat_id or create_chat(title=question[:40])["id"]
    append_message(chat_id, "user", question)

    if question.lower() in ["hi", "hello", "hey"]:
        ans = "Hello! Ask me anything about your county data."
        append_message(chat_id, "assistant", ans)
        return {"answer": ans, "chat_id": chat_id}

    try:
        chat_data = get_chat(chat_id)
        history   = chat_data.get("messages", []) if chat_data else []
        raw_sql   = generate_sql(question, history[:-1])
        sql       = fix_sql(raw_sql, question)
        print("FINAL SQL:", sql)

        if not sql.lower().startswith("select"):
            ans = "I couldn't generate a valid SQL query. Could you rephrase?"
            append_message(chat_id, "assistant", ans)
            return {"answer": ans, "chat_id": chat_id}

        if any(x in sql.lower() for x in ["drop", "delete", "update", "insert", "truncate", "alter"]):
            ans = "Unsafe query blocked. Only SELECT queries are allowed."
            append_message(chat_id, "assistant", ans)
            return {"answer": ans, "chat_id": chat_id}

        data   = execute_sql(sql)
        result = format_response(data, question)
        append_message(chat_id, "assistant", result.get("answer", "Done."))
        result["chat_id"] = chat_id
        return result

    except RuntimeError as e:
        err = str(e); append_message(chat_id, "assistant", err)
        return {"answer": err, "chat_id": chat_id}
    except Exception as e:
        err = f"Error: {str(e)}"; log.error(err)
        append_message(chat_id, "assistant", err)
        return {"answer": err, "chat_id": chat_id}

# ─────────────────────────────────────────────────────────────────
#  IN-MEMORY STATUS STORE
# ─────────────────────────────────────────────────────────────────
_upload_status: dict = {}


# ─────────────────────────────────────────────────────────────────
#  HELPERS FOR DOCUMENT UPLOAD
# ─────────────────────────────────────────────────────────────────
def _get_property_id(row: dict) -> str | None:
    for key in row:
        k = key.replace("\ufeff", "").lower().replace(" ", "").replace("_", "")
        if "propertyid" in k or "accountnumber" in k or "account" in k:
            val = row[key].strip()
            if val:
                return val
    return None


def _extract_pids_from_csv_bytes(content: bytes) -> list[str]:
    text   = content.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    pids   = []
    for row in reader:
        pid = _get_property_id(row)
        if pid:
            pids.append(pid)
    return pids


def _extract_pids_from_xlsx_bytes(content: bytes) -> list[str]:
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(h).strip() if h is not None else "" for h in rows[0]]
    pids = []
    for row in rows[1:]:
        row_dict = dict(zip(headers, [str(c).strip() if c is not None else "" for c in row]))
        pid = _get_property_id(row_dict)
        if pid:
            pids.append(pid)
    return pids


def _run_db_update_for_upload(county: str, csv_pids: list[str]) -> dict:
    conn   = get_db()
    cursor = conn.cursor()
    cursor.fast_executemany = True

    cursor.execute(
        "SELECT CountyId FROM ptax_County_Test WHERE CountyName = ?", county
    )
    row = cursor.fetchone()
    if not row:
        conn.close()
        raise ValueError(f"County '{county}' not found in ptax_County_Test")
    county_id = row[0]

    cursor.execute(
        "SELECT COUNT(*) FROM ptax_account_test WHERE CountyId = ?", county_id
    )
    total_accounts = cursor.fetchone()[0]

    cursor.execute("DELETE FROM PTAX_AofA_Staging WHERE CountyName = ?", county)
    if csv_pids:
        cursor.executemany(
            "INSERT INTO PTAX_AofA_Staging (PropertyId, CountyName) VALUES (?, ?)",
            [(pid, county) for pid in csv_pids],
        )
    conn.commit()

    cursor.execute(
        "SELECT AccountId, AccountNumber FROM ptax_account_test WHERE CountyId = ?",
        county_id,
    )
    db_rows        = cursor.fetchall()
    db_account_map = {r[1].strip(): r[0] for r in db_rows}
    db_acct_set    = set(db_account_map.keys())
    csv_pids_set   = set(csv_pids)

    matched_pids   = [p for p in csv_pids if p in db_acct_set]
    unmatched_pids = [p for p in csv_pids if p not in db_acct_set]

    cursor.execute("""
        SELECT a.AccountNumber
        FROM PTAX_AofA_Test t
        JOIN ptax_account_test a ON a.AccountId = t.AccountId
        WHERE a.CountyId = ? AND t.DateCoded IS NOT NULL
    """, county_id)
    currently_coded     = {r[0].strip() for r in cursor.fetchall()}
    expired_pids        = [a for a in currently_coded if a not in csv_pids_set]
    datecoded_end_count = len(expired_pids)

    cursor.execute("""
        SELECT a.AccountNumber
        FROM PTAX_AofA_Test t
        JOIN ptax_account_test a ON a.AccountId = t.AccountId
        WHERE a.CountyId = ?
    """, county_id)
    existing_aofa  = {r[0].strip() for r in cursor.fetchall()}
    updated_pids   = [p for p in matched_pids if p in existing_aofa]
    inserted_pids  = [p for p in matched_pids if p not in existing_aofa]

    cursor.execute("EXEC USP_Update_DateCoded_Fast @CountyName = ?", county)
    conn.commit()
    cursor.close()
    conn.close()

    return {
        "totalAccounts":     total_accounts,
        "totalCsv":          len(csv_pids),
        "datecodedUpdated":  len(updated_pids),
        "datecodedEnd":      datecoded_end_count,
        "insertedCount":     len(inserted_pids),
        "successCount":      len(matched_pids),
        "failureCount":      len(unmatched_pids),
        "successPids":       matched_pids,
        "failurePids":       unmatched_pids,
        "updatedPids":       updated_pids,
        "expiredPids":       expired_pids,
        "insertedPids":      inserted_pids
    }


def _save_uploaded_file_and_trigger_download(
    content: bytes,
    county: str,
    filename: str,
    ext: str,
):
    """
    Save the uploaded file to the shared folder (same path as autodownload.py)
    so the sidecar + folder structure stays consistent.
    Then trigger autodownload for that county in the background.
    """
    # ── Reverse-lookup county code from display name ──────────
    county_code = next(
        (code for code, name in COUNTY_MAP.items() if name == county),
        county.lower()
    )

    folder = Path(BASE_PATH) / county_code
    folder.mkdir(parents=True, exist_ok=True)

    ist_now  = now_ist()
    ts_str   = ist_now.strftime("%Y%m%d_%H%M%S")
    year     = str(ist_now.year)
    out_path = folder / f"{county_code}_{year}_{ts_str}{'.csv' if ext == 'csv' else '.xlsx'}"

    with open(out_path, "wb") as f:
        f.write(content)

    log.info(f"📁 Uploaded file saved → {out_path}")

    # ── Now trigger autodownload for this county ───────────────
    # Find matching entry in COUNTIES_CONFIG
    for url, agent_codes, dl_year in COUNTIES_CONFIG:
        code   = county_name_from_url(url)
        mapped = COUNTY_MAP.get(code, "")
        if mapped.lower() == county.lower():
            try:
                from autodownload import download_county
                import threading
                t = threading.Thread(
                    target=download_county,
                    args=(url, agent_codes, dl_year),
                    daemon=True,
                )
                t.start()
                log.info(f"🚀 autodownload triggered for {county} in background thread")
            except Exception as e:
                log.warning(f"Could not trigger autodownload for {county}: {e}")
            break


# ─────────────────────────────────────────────────────────────────
#  ROUTE: POST /documents/upload
# ─────────────────────────────────────────────────────────────────
@app.post("/documents/upload")
async def upload_document(
    background_tasks: BackgroundTasks,
    file:   UploadFile = File(...),
    county: str        = Form("Bell"),
):
    upload_id = str(uuid.uuid4())
    filename  = file.filename or "upload.csv"
    ext       = filename.rsplit(".", 1)[-1].lower()

    if ext not in ("csv", "xlsx", "xls"):
        raise HTTPException(status_code=400, detail="Only CSV or Excel files are supported.")

    content = await file.read()

    # ── 1. Extract property IDs ────────────────────────────────
    try:
        if ext == "csv":
            csv_pids = _extract_pids_from_csv_bytes(content)
        else:
            csv_pids = _extract_pids_from_xlsx_bytes(content)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Could not parse file: {e}")

    if not csv_pids:
        raise HTTPException(
            status_code=422,
            detail="No property IDs found. Make sure the file has a column named 'PropertyId' or 'AccountNumber'.",
        )

    # ── 2. Run DB update (SP call) ─────────────────────────────
    try:
        stats = _run_db_update_for_upload(county, csv_pids)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        log.error(f"DB update failed for uploaded file: {e}")
        raise HTTPException(status_code=500, detail=f"DB update failed: {e}")

    # ── 3. Save file + trigger autodownload in background ──────
    background_tasks.add_task(
        _save_uploaded_file_and_trigger_download,
        content, county, filename, ext
    )

    # ── 4. Return result ───────────────────────────────────────
    ist_now = now_ist()
    result  = {
        "id":       upload_id,
        "filename": filename,
        "county":   county,
        "date":     format_ist_datetime(ist_now),
        "time":     format_ist_time(ist_now),
        "status":   "success",
        **stats,
    }
    _upload_status[upload_id] = result
    return result


# ─────────────────────────────────────────────────────────────────
#  ROUTE: GET /documents/status/{upload_id}
# ─────────────────────────────────────────────────────────────────
@app.get("/documents/status/{upload_id}")
def get_upload_status(upload_id: str):
    result = _upload_status.get(upload_id)
    if not result:
        raise HTTPException(status_code=404, detail="Upload ID not found")
    return result
import { useState, useRef, useEffect } from "react";
import {
  MessageSquare, LayoutDashboard, Database, FileText, Clock,
  Settings, Plus, Send, Moon, Sun, Bot, Users, TrendingUp,
  AlertCircle, MapPin, Upload, RefreshCw, CheckCircle2, XCircle, Trash2
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";
import AutomationPage from "./AutomationPage";
import DocumentsPage from "./DocumentsPage";

import { API, NGROK_HEADERS } from "./config";

// ─────────────────────────────────────────────────────────────────
//  THEME TOKENS
// ─────────────────────────────────────────────────────────────────
const THEMES = {
  light: {
    bg: "#f5f5f6", sb: "#ffffff", card: "#ffffff",
    bd: "#e4e4e7", txt: "#18181b", sub: "#71717a", mut: "#a1a1aa",
    acc: "#6366f1", acFg: "#ffffff",
    inp: "#ffffff", inpBd: "#d4d4d8",
    uBg: "#eef2ff", bBg: "#ffffff", bBd: "#e4e4e7",
    actBg: "#eef2ff", actTxt: "#4338ca",
    met: "#f4f4f5", pre: "#f4f4f5",
    tag: "#f4f4f5", tagTxt: "#52525b",
    green: "#10b981", red: "#ef4444",
    chatHover: "#f4f4f5",
  },
  dark: {
    bg: "#0c0c0e", sb: "#111114", card: "#18181b",
    bd: "#27272a", txt: "#fafafa", sub: "#a1a1aa", mut: "#52525b",
    acc: "#818cf8", acFg: "#ffffff",
    inp: "#18181b", inpBd: "#3f3f46",
    uBg: "#1e1b4b", bBg: "#18181b", bBd: "#27272a",
    actBg: "#1e1b4b", actTxt: "#818cf8",
    met: "#27272a", pre: "#0c0c0e",
    tag: "#27272a", tagTxt: "#a1a1aa",
    green: "#10b981", red: "#f87171",
    chatHover: "#27272a",
  },
};

const REV = [
  {m:"Jan",v:41200},{m:"Feb",v:53800},{m:"Mar",v:48900},{m:"Apr",v:61200},
  {m:"May",v:55400},{m:"Jun",v:72300},{m:"Jul",v:68100},{m:"Aug",v:79500},
  {m:"Sep",v:83200},{m:"Oct",v:91400},{m:"Nov",v:87600},{m:"Dec",v:96200},
];
const CTY = [
  {c:"LA",n:234},{c:"SD",n:189},{c:"SF",n:156},
  {c:"OC",n:143},{c:"RV",n:98},{c:"SB",n:76},
];
const BILLS = [
  {name:"Property Tax",v:42},{name:"Utility",v:28},
  {name:"Assessment",v:18},{name:"Other",v:12},
];
const PC = ["#6366f1","#06b6d4","#f59e0b","#10b981"];

const INIT_MSGS = [
  {
    role: "assistant", time: "9:00 AM",
    blocks: [
      { t: "p", c: "Welcome to **DataPortal AI**. How can i help you today." },
    ],
  },
];

function Blocks({ data, c }) {
  return data.map((b, i) => {
    if (b.t === "p") {
      const parts = b.c.split(/(\*\*[^*]+\*\*)/g);
      return (
        <p key={i} style={{ margin: "0 0 10px", lineHeight: 1.65, fontSize: 14, color: c.txt }}>
          {parts.map((p, j) =>
            p.startsWith("**")
              ? <strong key={j} style={{ fontWeight: 600 }}>{p.slice(2, -2)}</strong>
              : p
          )}
        </p>
      );
    }
    if (b.t === "suggestions") return (
      <div key={i} style={{ display: "flex", flexDirection: "column", gap: 7, marginTop: 6 }}>
        {b.c.map((s, j) => (
          <div key={j} style={{ display: "inline-flex", alignItems: "center", gap: 9, padding: "8px 13px", background: c.met, border: `1px solid ${c.bd}`, borderRadius: 9, fontSize: 13, color: c.sub, cursor: "pointer" }}>
            <MessageSquare size={12} style={{ flexShrink: 0 }} /> {s}
          </div>
        ))}
      </div>
    );
    if (b.t === "sql") return (
      <div key={i} style={{ background: c.pre, border: `1px solid ${c.bd}`, borderRadius: 9, margin: "10px 0", overflow: "hidden" }}>
        <div style={{ padding: "7px 14px", borderBottom: `1px solid ${c.bd}`, fontSize: 10, fontWeight: 600, letterSpacing: "0.07em", color: c.sub, fontFamily: "monospace", display: "flex", alignItems: "center", gap: 6 }}>
          <Database size={10} /> SQL GENERATED
        </div>
        <pre style={{ margin: 0, padding: "12px 14px", fontFamily: `ui-monospace,"Cascadia Code",Menlo,monospace`, fontSize: 12, lineHeight: 1.75, whiteSpace: "pre-wrap", color: c.txt, overflowX: "auto" }}>{b.c}</pre>
      </div>
    );
    if (b.t === "list") return (
      <div key={i} style={{ display: "flex", flexDirection: "column", gap: 5, margin: "8px 0" }}>
        {b.c.map((item, j) => (
          <div key={j} style={{ display: "flex", alignItems: "flex-start", gap: 9, padding: "8px 12px", background: c.met, borderRadius: 7, fontSize: 13, color: c.txt, lineHeight: 1.5 }}>
            <span style={{ width: 18, height: 18, borderRadius: "50%", background: c.actBg, color: c.acc, fontSize: 10, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1 }}>{j + 1}</span>
            <span style={{ flex: 1, wordBreak: "break-word" }}>{item}</span>
          </div>
        ))}
      </div>
    );
    if (b.t === "table") return (
      <div key={i} style={{ borderRadius: 9, border: `1px solid ${c.bd}`, overflow: "auto", margin: "10px 0", maxHeight: 380 }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead style={{ position: "sticky", top: 0, zIndex: 1 }}>
            <tr style={{ background: c.met }}>
              {b.headers.map((h, j) => (
                <th key={j} style={{ padding: "9px 14px", fontWeight: 600, fontSize: 11, color: c.sub, textAlign: "left", borderBottom: `1px solid ${c.bd}`, whiteSpace: "nowrap" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {b.rows.map((row, j) => (
              <tr key={j} style={{ borderBottom: j < b.rows.length - 1 ? `1px solid ${c.bd}` : "none", background: j % 2 === 1 ? c.met : "transparent" }}>
                {row.map((cell, k) => (
                  <td key={k} style={{ padding: "9px 14px", textAlign: "left", fontSize: 13, color: c.txt, whiteSpace: "nowrap", maxWidth: 260, overflow: "hidden", textOverflow: "ellipsis" }}>{cell}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
    return null;
  });
}

const SOURCES = [
  { name: "LA County Portal", county: "Los Angeles", status: "synced", clients: 234, last: "Today 9:00 AM", schedule: "Daily" },
  { name: "SD County Portal", county: "San Diego", status: "synced", clients: 189, last: "Today 8:55 AM", schedule: "Daily" },
  { name: "SF County Portal", county: "San Francisco", status: "synced", clients: 156, last: "Today 9:01 AM", schedule: "Weekly" },
  { name: "OC County Portal", county: "Orange County", status: "syncing", clients: 143, last: "In progress…", schedule: "Daily" },
  { name: "Riverside Portal", county: "Riverside", status: "error", clients: 98, last: "Failed 8:30 AM", schedule: "15 days" },
  { name: "Santa Barbara", county: "Santa Barbara", status: "synced", clients: 76, last: "Yesterday 6:00 PM", schedule: "Weekly" },
];

export default function App() {
  const [mode, setMode] = useState("light");
  const [nav, setNav] = useState("chat");
  const [msgs, setMsgs] = useState(INIT_MSGS);
  const [inp, setInp] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef(null);

  const [activeChatId, setActiveChatId] = useState(null);
  const [savedChats, setSavedChats] = useState([]);
  const [chatsLoading, setChatsLoading] = useState(false);
  const [hoveredChat, setHoveredChat] = useState(null);

  const c = THEMES[mode];
  const isDark = mode === "dark";

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [msgs, busy]);

  useEffect(() => {
    fetchSavedChats();
  }, []);

  const fetchSavedChats = async () => {
    setChatsLoading(true);
    try {
      const res = await fetch(`${API}/chats`, { headers: NGROK_HEADERS });
      const data = await res.json();
      setSavedChats(data);
    } catch (err) {
      console.error("Could not load chat history:", err);
    }
    setChatsLoading(false);
  };

  const loadChat = async (chatId) => {
    try {
      const res = await fetch(`${API}/chats/${chatId}`, { headers: NGROK_HEADERS });
      const data = await res.json();
      if (data.error) return;
      const restored = [
        ...INIT_MSGS,
        ...data.messages.map(m => ({
          role: m.role,
          time: m.time,
          ...(m.role === "user"
            ? { text: m.content }
            : { blocks: [{ t: "p", c: m.content }] }
          ),
        })),
      ];
      setMsgs(restored);
      setActiveChatId(chatId);
      setNav("chat");
    } catch (err) {
      console.error("Could not load chat:", err);
    }
  };

  const deleteChat = async (chatId, e) => {
    e.stopPropagation();
    try {
      await fetch(`${API}/chats/${chatId}`, { method: "DELETE", headers: NGROK_HEADERS });
      setSavedChats(prev => prev.filter(ch => ch.id !== chatId));
      if (chatId === activeChatId) {
        setMsgs(INIT_MSGS);
        setActiveChatId(null);
      }
    } catch (err) {
      console.error("Could not delete chat:", err);
    }
  };

  const startNewChat = () => {
    setMsgs(INIT_MSGS);
    setActiveChatId(null);
    setNav("chat");
    setInp("");
  };

  const send = async () => {
    if (!inp.trim() || busy) return;
    const q = inp.trim();
    const t = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    setMsgs(m => [...m, { role: "user", time: t, text: q }]);
    setInp("");
    setBusy(true);
    try {
      const res = await fetch(`${API}/ask`, {
        method: "POST",
        headers: { ...NGROK_HEADERS, "Content-Type": "application/json" },
        body: JSON.stringify({ question: q, chat_id: activeChatId }),
      });
      const data = await res.json();
      if (data.chat_id) {
        setActiveChatId(data.chat_id);
        fetchSavedChats();
      }
      const ts = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      const blocks = [];
      if (data.answer) blocks.push({ t: "p", c: data.answer });
      if (data.list && data.list.length > 0) blocks.push({ t: "list", c: data.list });
      if (data.data && data.data.length > 0) {
        const headers = Object.keys(data.data[0]);
        const rows = data.data.map(row => headers.map(h => {
          const v = row[h];
          return v === null || v === undefined ? "—" : String(v);
        }));
        blocks.push({ t: "table", headers, rows });
      }
      if (blocks.length === 0) blocks.push({ t: "p", c: "No response received from backend." });
      setMsgs(m => [...m, { role: "assistant", time: ts, blocks }]);
    } catch (err) {
      console.error(err);
      const ts = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      setMsgs(m => [...m, {
        role: "assistant", time: ts,
        blocks: [{ t: "p", c: `⚠️ Could not connect to backend at ${API}. Make sure FastAPI is running.` }]
      }]);
    }
    setBusy(false);
  };

  const NAV_ITEMS = [
    { id: "chat", label: "Chat", Icon: MessageSquare },
    { id: "documents", label: "Documents", Icon: FileText },
    { id: "automation", label: "Automation", Icon: Clock },
  ];

  const METRICS = [
    { l: "Total Clients", v: "2,341", ch: "+12.4%", up: true, Icon: Users },
    { l: "Monthly Revenue", v: "$96,200", ch: "+9.8%", up: true, Icon: TrendingUp },
    { l: "Active Counties", v: "6 / 6", ch: "All online", up: null, Icon: MapPin },
    { l: "Pending Bills", v: "187", ch: "-3.2%", up: false, Icon: AlertCircle },
  ];

  const statusColor = (s) => s === "synced" ? c.green : s === "syncing" ? c.acc : c.red;
  const statusLabel = (s) => s === "synced" ? "Synced" : s === "syncing" ? "Syncing…" : "Error";
  const StatusIcon = ({ s }) =>
    s === "synced" ? <CheckCircle2 size={14} color={c.green} /> :
    s === "syncing" ? <RefreshCw size={14} color={c.acc} style={{ animation: "spin 1.5s linear infinite" }} /> :
    <XCircle size={14} color={c.red} />;

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "ui-sans-serif,system-ui,-apple-system,sans-serif", background: c.bg, color: c.txt, overflow: "hidden" }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: ${c.bd}; border-radius: 4px; }
        button, textarea { font-family: inherit; cursor: pointer; }
        textarea { resize: none; outline: none; }
        @keyframes dot { 0%,100%{opacity:.2;transform:scale(.7)} 50%{opacity:1;transform:scale(1)} }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        button:hover { opacity: 0.85; }
        .chat-item:hover .delete-btn { opacity: 1 !important; }
      `}</style>

      <aside style={{ width: 248, flexShrink: 0, background: c.sb, borderRight: `1px solid ${c.bd}`, display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "18px 16px 14px", display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: c.acc, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <Database size={16} color="#fff" strokeWidth={2.2} />
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, letterSpacing: -0.4 }}>DataPortal</div>
            <div style={{ fontSize: 10, color: c.mut, marginTop: 1 }}>AI Analytics Platform</div>
          </div>
        </div>

        <div style={{ padding: "0 12px 10px" }}>
          <button onClick={startNewChat} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 7, padding: "8px", background: "transparent", border: `1px solid ${c.bd}`, borderRadius: 8, color: c.txt, fontSize: 13, fontWeight: 500 }}>
            <Plus size={14} /> New Chat
          </button>
        </div>

        <nav style={{ padding: "2px 8px 4px", display: "flex", flexDirection: "column", gap: 1 }}>
          {NAV_ITEMS.map(({ id, label, Icon }) => {
            const active = nav === id;
            return (
              <button key={id} onClick={() => setNav(id)}
                style={{ display: "flex", alignItems: "center", gap: 9, padding: "9px 12px", background: active ? c.actBg : "transparent", border: "none", borderRadius: 8, color: active ? c.actTxt : c.sub, fontSize: 13, fontWeight: active ? 600 : 400, textAlign: "left", transition: "all .15s" }}>
                <Icon size={15} strokeWidth={active ? 2.2 : 1.75} />
                {label}
              </button>
            );
          })}
        </nav>

        <div style={{ height: 1, background: c.bd, margin: "8px 14px" }} />

        <div style={{ flex: 1, overflow: "auto", padding: "0 8px" }}>
          <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.07em", color: c.mut, padding: "4px 12px 6px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span>RECENT CHATS</span>
            <span style={{ fontWeight: 400 }}>{savedChats.length}/5</span>
          </div>
          {chatsLoading && <div style={{ padding: "8px 12px", fontSize: 12, color: c.mut }}>Loading…</div>}
          {!chatsLoading && savedChats.length === 0 && (
            <div style={{ padding: "8px 12px", fontSize: 12, color: c.mut }}>No saved chats yet. Start chatting!</div>
          )}
          {savedChats.map((chat) => {
            const isActive = chat.id === activeChatId;
            const isHov = hoveredChat === chat.id;
            return (
              <div key={chat.id} className="chat-item"
                onMouseEnter={() => setHoveredChat(chat.id)}
                onMouseLeave={() => setHoveredChat(null)}
                style={{ display: "flex", alignItems: "center", borderRadius: 7, background: isActive ? c.actBg : isHov ? c.chatHover : "transparent", marginBottom: 2, transition: "background .12s" }}>
                <button onClick={() => loadChat(chat.id)}
                  style={{ flex: 1, textAlign: "left", padding: "7px 12px", background: "transparent", border: "none", borderRadius: 7, color: isActive ? c.actTxt : c.sub, fontSize: 12, fontWeight: isActive ? 600 : 400, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>
                  {chat.title}
                </button>
                <button className="delete-btn" onClick={(e) => deleteChat(chat.id, e)} title="Delete chat"
                  style={{ flexShrink: 0, padding: "4px 6px", background: "transparent", border: "none", color: c.mut, fontSize: 11, borderRadius: 5, marginRight: 4, cursor: "pointer", opacity: isHov || isActive ? 1 : 0, transition: "opacity .15s" }}>
                  <Trash2 size={12} />
                </button>
              </div>
            );
          })}
        </div>

        <div style={{ padding: "10px 8px", borderTop: `1px solid ${c.bd}` }}>
          <button onClick={() => setMode(m => m === "light" ? "dark" : "light")}
            style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", background: "transparent", border: `1px solid ${c.bd}`, borderRadius: 8, color: c.sub, fontSize: 12, marginBottom: 6 }}>
            {isDark ? <Sun size={13} /> : <Moon size={13} />}
            {isDark ? "Light Mode" : "Dark Mode"}
          </button>
          <button style={{ width: "100%", display: "flex", alignItems: "center", gap: 9, padding: "8px 12px", background: "transparent", border: "none", borderRadius: 8, color: c.sub, fontSize: 12 }}>
            <div style={{ width: 27, height: 27, borderRadius: "50%", background: c.acc, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: "#fff", fontWeight: 700, flexShrink: 0 }}>A</div>
            <span style={{ flex: 1, textAlign: "left", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>Admin User</span>
            <Settings size={12} />
          </button>
        </div>
      </aside>

      <main style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {nav === "chat" && <>
          <header style={{ padding: "12px 24px", borderBottom: `1px solid ${c.bd}`, background: c.sb, display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: c.actBg, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Bot size={18} color={c.acc} strokeWidth={1.75} />
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>County Data Assistant</div>
              <div style={{ fontSize: 11, color: c.sub }}>
                6 portals connected · 2,341 clients indexed
                {activeChatId && <span style={{ marginLeft: 8, color: c.acc }}>● Chat saved</span>}
              </div>
            </div>
            <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6, padding: "5px 12px", background: c.met, borderRadius: 20, fontSize: 11, color: c.sub }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: c.green, display: "inline-block" }} />
              Online
            </div>
          </header>

          <div ref={scrollRef} style={{ flex: 1, overflow: "auto", padding: "24px" }}>
            <div style={{ maxWidth: 780, margin: "0 auto", display: "flex", flexDirection: "column", gap: 20 }}>
              {msgs.map((msg, i) => (
                <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", flexDirection: msg.role === "user" ? "row-reverse" : "row" }}>
                  <div style={{ width: 34, height: 34, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: msg.role === "user" ? c.uBg : c.actBg, fontSize: 12, fontWeight: 700, color: c.acc }}>
                    {msg.role === "user" ? "A" : <Bot size={16} color={c.acc} strokeWidth={1.75} />}
                  </div>
                  <div style={{ maxWidth: "76%", minWidth: 0 }}>
                    <div style={{ background: msg.role === "user" ? c.uBg : c.bBg, border: `1px solid ${msg.role === "user" ? "transparent" : c.bBd}`, borderRadius: msg.role === "user" ? "16px 4px 16px 16px" : "4px 16px 16px 16px", padding: "12px 16px" }}>
                      {msg.text
                        ? <p style={{ margin: 0, fontSize: 14, lineHeight: 1.6, color: c.txt }}>{msg.text}</p>
                        : <Blocks data={msg.blocks} c={c} />}
                    </div>
                    <div style={{ fontSize: 11, color: c.mut, margin: "4px 6px 0", textAlign: msg.role === "user" ? "right" : "left" }}>{msg.time}</div>
                  </div>
                </div>
              ))}
              {busy && (
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <div style={{ width: 34, height: 34, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: c.actBg }}>
                    <Bot size={16} color={c.acc} strokeWidth={1.75} />
                  </div>
                  <div style={{ background: c.bBg, border: `1px solid ${c.bBd}`, borderRadius: "4px 16px 16px 16px", padding: "15px 18px", display: "flex", gap: 5, alignItems: "center" }}>
                    {[0, 1, 2].map(j => <span key={j} style={{ width: 7, height: 7, borderRadius: "50%", background: c.acc, display: "inline-block", animation: `dot 1.2s ${j * 0.22}s infinite` }} />)}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div style={{ padding: "12px 24px 18px", background: c.sb, borderTop: `1px solid ${c.bd}`, flexShrink: 0 }}>
            <div style={{ maxWidth: 780, margin: "0 auto" }}>
              <div style={{ display: "flex", alignItems: "flex-end", gap: 10, background: c.inp, border: `1px solid ${c.inpBd}`, borderRadius: 14, padding: "10px 12px 10px 16px" }}>
                <textarea value={inp} onChange={e => setInp(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                  placeholder="Ask about county data, bills, clients…" rows={1}
                  style={{ flex: 1, background: "transparent", border: "none", color: c.txt, fontSize: 14, lineHeight: 1.5, maxHeight: 120, overflowY: "auto", paddingTop: 2 }} />
                <button onClick={send} disabled={!inp.trim() || busy}
                  style={{ width: 34, height: 34, flexShrink: 0, borderRadius: 9, border: "none", background: inp.trim() && !busy ? c.acc : c.met, display: "flex", alignItems: "center", justifyContent: "center", cursor: inp.trim() && !busy ? "pointer" : "default", transition: "all .2s" }}>
                  <Send size={14} color={inp.trim() && !busy ? "#fff" : c.mut} strokeWidth={2} />
                </button>
              </div>
              <p style={{ fontSize: 11, color: c.mut, textAlign: "center", marginTop: 8 }}>DataPortal AI can make mistakes. Always verify critical financial data.</p>
            </div>
          </div>
        </>}

        
        {nav === "documents" && <DocumentsPage c={c} />}


        {nav === "automation" && <AutomationPage c={c} />}
      </main>
    </div>
  );
}
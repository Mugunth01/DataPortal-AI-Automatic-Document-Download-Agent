/**
 * AutomationPage.jsx
 * Changes:
 *  - DbViewModal: stats row IS the filter (clickable chips), no separate tab bar, no Inserted tab
 *  - DownloadViewModal: same pattern (Matched / Unmatched clickable stats)
 *  - County filter: searchable multi-select dropdown instead of pills
 */

import { useState, useEffect, useCallback, useRef } from "react";
import {
  CheckCircle2, XCircle, Clock, TrendingUp, RefreshCw,
  Download, ChevronDown, ChevronUp, Play, Database,
  FileText, AlertCircle, Eye, X, Calendar, Search,
} from "lucide-react";

import { API, NGROK_HEADERS } from "./config";
const fmt = (n) => (n ?? 0).toLocaleString();

function toIST(t)  { return t ? `${t} IST` : "—"; }
function toISTDate(s) {
  if (!s) return "—";
  try {
    const [y,m,d] = s.split("-");
    const mo = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return `${d} ${mo[parseInt(m,10)-1]} ${y}`;
  } catch { return s; }
}

// ── Status Badge ─────────────────────────────────────────────────
function StatusBadge({ ok, c }) {
  return (
    <span style={{
      display:"inline-flex",alignItems:"center",gap:4,
      fontSize:11,fontWeight:600,padding:"3px 9px",borderRadius:20,
      background: ok?`${c.green}22`:`${c.red}22`,
      color: ok?c.green:c.red,
    }}>
      {ok?<CheckCircle2 size={11}/>:<XCircle size={11}/>}
      {ok?"Success":"Error"}
    </span>
  );
}

// ── Calendar Picker ──────────────────────────────────────────────
function CalendarPicker({ value, onConfirm, c }) {
  const [open,   setOpen]   = useState(false);
  const [picked, setPicked] = useState(value||"");
  const ref = useRef(null);
  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const label = picked
    ? new Date(picked+"T00:00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})
    : "Pick date";
  return (
    <div ref={ref} style={{position:"relative"}}>
      <button onClick={()=>setOpen(!open)} style={{
        display:"flex",alignItems:"center",gap:6,
        padding:"5px 14px",borderRadius:20,fontSize:12,fontWeight:500,
        border:`1px solid ${open?c.acc:c.bd}`,
        background:open?c.actBg:"transparent",
        color:open?c.actTxt:c.sub,cursor:"pointer",
      }}>
        <Calendar size={12}/> {label}
      </button>
      {open && (
        <div style={{
          position:"absolute",top:"calc(100% + 6px)",left:0,
          background:c.card,border:`1px solid ${c.bd}`,
          borderRadius:12,padding:16,zIndex:200,
          boxShadow:"0 8px 32px rgba(0,0,0,0.18)",
          display:"flex",flexDirection:"column",gap:10,minWidth:220,
        }}>
          <div style={{fontSize:11,color:c.sub,fontWeight:600}}>SELECT DATE</div>
          <input type="date" value={picked} max={new Date().toISOString().slice(0,10)}
            onChange={e=>setPicked(e.target.value)}
            style={{border:`1px solid ${c.bd}`,borderRadius:8,padding:"7px 10px",fontSize:13,background:c.met,color:c.txt,outline:"none",width:"100%",boxSizing:"border-box"}}
          />
          <button disabled={!picked} onClick={()=>{onConfirm(picked);setOpen(false);}} style={{
            padding:"8px 0",background:picked?c.acc:c.bd,border:"none",borderRadius:8,
            color:picked?"#fff":c.sub,fontSize:13,fontWeight:600,
            cursor:picked?"pointer":"not-allowed",
          }}>✓ Confirm &amp; Search</button>
        </div>
      )}
    </div>
  );
}

// ── County Multi-Select Dropdown ─────────────────────────────────
function CountyDropdown({ counties, selected, onChange, c }) {
  const [open,   setOpen]   = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef(null);

  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const filtered  = counties.filter(c => c.toLowerCase().includes(search.toLowerCase()));
  const allSel    = selected.length === 0 || selected.length === counties.length;
  const label     = allSel ? "All Counties" : selected.length === 1 ? selected[0] : `${selected.length} counties`;

  const toggle = (co) => {
    if (selected.includes(co)) onChange(selected.filter(x=>x!==co));
    else onChange([...selected, co]);
  };
  const toggleAll = () => {
    onChange(allSel ? [] : [...counties]);
  };

  if (!counties.length) return null;

  return (
    <div ref={ref} style={{position:"relative",display:"inline-block"}}>
      <button onClick={()=>setOpen(!open)} style={{
        display:"flex",alignItems:"center",gap:8,
        padding:"6px 14px",borderRadius:8,
        border:`1px solid ${open?c.acc:c.bd}`,
        background:open?c.actBg:c.card,
        color:open?c.actTxt:c.txt,
        fontSize:13,fontWeight:500,cursor:"pointer",
        minWidth:160,
      }}>
        <Database size={13} color={open?c.acc:c.mut}/>
        <span style={{flex:1,textAlign:"left"}}>{label}</span>
        <ChevronDown size={13} style={{transform:open?"rotate(180deg)":"none",transition:"transform .15s"}}/>
      </button>

      {open && (
        <div style={{
          position:"absolute",top:"calc(100% + 4px)",left:0,
          background:c.card,border:`1px solid ${c.bd}`,
          borderRadius:10,zIndex:200,minWidth:200,
          boxShadow:"0 8px 32px rgba(0,0,0,0.15)",
          overflow:"hidden",
        }}>
          {/* Search */}
          <div style={{padding:"8px 10px",borderBottom:`1px solid ${c.bd}`,display:"flex",alignItems:"center",gap:6}}>
            <Search size={12} color={c.sub}/>
            <input
              value={search} onChange={e=>setSearch(e.target.value)}
              placeholder="Search county…"
              style={{flex:1,background:"transparent",border:"none",outline:"none",fontSize:12,color:c.txt}}
              autoFocus
            />
          </div>
          {/* All option */}
          <div
            onClick={toggleAll}
            style={{
              padding:"8px 12px",display:"flex",alignItems:"center",gap:8,
              cursor:"pointer",fontSize:12,fontWeight:600,
              background:allSel?c.actBg:"transparent",
              color:allSel?c.actTxt:c.sub,
              borderBottom:`1px solid ${c.bd}`,
            }}
          >
            <span style={{
              width:14,height:14,borderRadius:3,border:`2px solid ${allSel?c.acc:c.bd}`,
              background:allSel?c.acc:"transparent",
              display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,
            }}>
              {allSel && <CheckCircle2 size={9} color="#fff"/>}
            </span>
            All Counties
          </div>
          {/* County options */}
          <div style={{maxHeight:180,overflow:"auto"}}>
            {filtered.map(co => {
              const isSel = selected.includes(co);
              return (
                <div key={co} onClick={()=>toggle(co)} style={{
                  padding:"8px 12px",display:"flex",alignItems:"center",gap:8,
                  cursor:"pointer",fontSize:12,
                  background:isSel?`${c.acc}10`:"transparent",
                  color:isSel?c.actTxt:c.txt,
                }}>
                  <span style={{
                    width:14,height:14,borderRadius:3,
                    border:`2px solid ${isSel?c.acc:c.bd}`,
                    background:isSel?c.acc:"transparent",
                    display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,
                  }}>
                    {isSel && <CheckCircle2 size={9} color="#fff"/>}
                  </span>
                  {co}
                </div>
              );
            })}
            {filtered.length===0 && <div style={{padding:"10px 12px",fontSize:12,color:c.sub}}>No results</div>}
          </div>
          {/* Apply */}
          <div style={{padding:"8px 10px",borderTop:`1px solid ${c.bd}`}}>
            <button onClick={()=>setOpen(false)} style={{
              width:"100%",padding:"6px",background:c.acc,
              border:"none",borderRadius:6,color:"#fff",fontSize:12,fontWeight:600,cursor:"pointer",
            }}>Apply</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── DB View Modal — stats chips ARE the filter, no separate tab bar ──
function DbViewModal({ row, onClose, c }) {
  // Filters: matched | unmatched | datecoded | dateend  (no inserted)
  const FILTERS = [
    { id:"matched",   label:"Matched",    pids:row.successPids||[], value:row.successCount,     color:c.green },
    { id:"unmatched", label:"Unmatched",  pids:row.failurePids||[], value:row.failureCount,     color:c.red   },
    { id:"datecoded", label:"DateCoded ↑",pids:row.updatedPids||[], value:row.datecodedUpdated, color:c.acc   },
    { id:"dateend",   label:"DateEnd ↑",  pids:row.expiredPids||[], value:row.datecodedEnd,     color:c.red   },
  ];

  const [active, setActive] = useState("matched");
  const [search, setSearch] = useState("");

  const current  = FILTERS.find(f=>f.id===active) || FILTERS[0];
  const filtered = search.trim()
    ? current.pids.filter(p=>p.toLowerCase().includes(search.trim().toLowerCase()))
    : current.pids;

  const exportCSV = () => {
    const blob = new Blob([filtered.join("\n")],{type:"text/csv"});
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href=url; a.download=`${row.county}_${active}_${row.date}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div onClick={onClose} style={{
      position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",
      zIndex:300,display:"flex",alignItems:"center",justifyContent:"center",
    }}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:c.card,border:`1px solid ${c.bd}`,
        borderRadius:16,width:680,maxHeight:"84vh",
        display:"flex",flexDirection:"column",overflow:"hidden",
        boxShadow:"0 24px 64px rgba(0,0,0,0.3)",
      }}>
        {/* Header */}
        <div style={{padding:"18px 22px",borderBottom:`1px solid ${c.bd}`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div>
            <div style={{fontWeight:700,fontSize:15}}>{row.county} — DB Update Results</div>
            <div style={{fontSize:11,color:c.sub,marginTop:3}}>
              Date: {toISTDate(row.date)} · Run time: {toIST(row.time)}
            </div>
          </div>
          <button onClick={onClose} style={{background:"transparent",border:"none",cursor:"pointer",color:c.sub}}><X size={18}/></button>
        </div>

        {/* ── Clickable stat chips — these ARE the filter ── */}
        <div style={{
          display:"flex",gap:0,padding:"14px 22px",
          borderBottom:`1px solid ${c.bd}`,flexWrap:"wrap",gap:10,
        }}>
          {/* Total Accounts — not a filter, just info */}
          <div style={{
            padding:"10px 18px",borderRadius:10,
            background:c.met,border:`1px solid ${c.bd}`,
            textAlign:"center",minWidth:90,
          }}>
            <div style={{fontSize:20,fontWeight:700,color:c.txt}}>{fmt(row.totalAccounts)}</div>
            <div style={{fontSize:10,color:c.sub,marginTop:3}}>Total Accounts</div>
          </div>

          {FILTERS.map(f=>{
            const isActive = active===f.id;
            return (
              <button
                key={f.id}
                onClick={()=>{ setActive(f.id); setSearch(""); }}
                style={{
                  padding:"10px 18px",borderRadius:10,
                  background: isActive ? `${f.color}18` : c.met,
                  border: isActive ? `2px solid ${f.color}` : `2px solid transparent`,
                  outline:"none",cursor:"pointer",
                  textAlign:"center",minWidth:90,
                  transition:"all .15s",
                }}
              >
                <div style={{fontSize:20,fontWeight:700,color:f.color}}>{fmt(f.value)}</div>
                <div style={{fontSize:10,color:isActive?f.color:c.sub,marginTop:3,fontWeight:isActive?600:400}}>
                  {f.label}
                </div>
              </button>
            );
          })}
        </div>

        {/* Search bar */}
        <div style={{padding:"10px 22px 8px",borderBottom:`1px solid ${c.bd}`}}>
          <div style={{display:"flex",alignItems:"center",gap:8,background:c.met,borderRadius:8,padding:"6px 12px"}}>
            <Search size={12} color={c.sub}/>
            <input
              value={search} onChange={e=>setSearch(e.target.value)}
              placeholder={`Search ${current.label} IDs…`}
              style={{flex:1,background:"transparent",border:"none",outline:"none",fontSize:12,color:c.txt}}
            />
            {search && (
              <button onClick={()=>setSearch("")} style={{background:"transparent",border:"none",cursor:"pointer",color:c.sub,padding:0}}>
                <X size={11}/>
              </button>
            )}
          </div>
          <div style={{fontSize:10,color:c.sub,marginTop:5}}>
            Showing {fmt(filtered.length)} of {fmt(current.pids.length)} IDs
          </div>
        </div>

        {/* PIDs */}
        <div style={{flex:1,overflow:"auto",padding:"12px 22px 16px"}}>
          {filtered.length===0
            ? <p style={{color:c.sub,fontSize:13,margin:0}}>No entries{search?" matching your search":""}.</p>
            : <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
                {filtered.map((pid,i)=>(
                  <span key={i} style={{
                    fontSize:11,padding:"3px 8px",fontFamily:"monospace",
                    background:`${current.color}14`,border:`1px solid ${current.color}44`,
                    borderRadius:5,color:current.color,
                  }}>{pid}</span>
                ))}
              </div>
          }
        </div>

        {/* Footer */}
        <div style={{padding:"10px 22px",borderTop:`1px solid ${c.bd}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <button onClick={exportCSV} style={{
            display:"flex",alignItems:"center",gap:6,padding:"6px 14px",
            background:"transparent",border:`1px solid ${c.bd}`,borderRadius:7,
            color:c.sub,fontSize:12,cursor:"pointer",
          }}><Download size={12}/> Export CSV</button>
          <button onClick={onClose} style={{padding:"7px 20px",background:c.acc,border:"none",borderRadius:8,color:"#fff",fontSize:13,cursor:"pointer"}}>Close</button>
        </div>
      </div>
    </div>
  );
}

// ── Download View Modal — same pattern ───────────────────────────
function DownloadViewModal({ row, onClose, c }) {
  const FILTERS = [
    { id:"matched",   label:"Matched",   pids:row.successPids||[], value:row.matched||0,                        color:c.green },
    { id:"unmatched", label:"Unmatched", pids:row.failPids||[],    value:(row.totalCsv||0)-(row.matched||0),    color:c.red   },
  ];

  const [active, setActive] = useState("matched");
  const [search, setSearch] = useState("");

  const current  = FILTERS.find(f=>f.id===active)||FILTERS[0];
  const filtered = search.trim()
    ? current.pids.filter(p=>p.toLowerCase().includes(search.trim().toLowerCase()))
    : current.pids;

  const exportCSV = () => {
    const blob = new Blob([filtered.join("\n")],{type:"text/csv"});
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href=url; a.download=`${row.county}_${active}_${row.date}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div onClick={onClose} style={{
      position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",
      zIndex:300,display:"flex",alignItems:"center",justifyContent:"center",
    }}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:c.card,border:`1px solid ${c.bd}`,
        borderRadius:16,width:620,maxHeight:"82vh",
        display:"flex",flexDirection:"column",overflow:"hidden",
        boxShadow:"0 24px 64px rgba(0,0,0,0.3)",
      }}>
        {/* Header */}
        <div style={{padding:"18px 22px",borderBottom:`1px solid ${c.bd}`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div>
            <div style={{fontWeight:700,fontSize:15}}>{row.county} — Match Results</div>
            <div style={{fontSize:11,color:c.sub,marginTop:3}}>Date: {toISTDate(row.date)} · Run time: {toIST(row.time)}</div>
          </div>
          <button onClick={onClose} style={{background:"transparent",border:"none",cursor:"pointer",color:c.sub}}><X size={18}/></button>
        </div>

        {/* Clickable stat chips */}
        <div style={{display:"flex",gap:10,padding:"14px 22px",borderBottom:`1px solid ${c.bd}`}}>
          {/* Total */}
          <div style={{padding:"10px 18px",borderRadius:10,background:c.met,border:`1px solid ${c.bd}`,textAlign:"center",minWidth:90}}>
            <div style={{fontSize:20,fontWeight:700,color:c.txt}}>{fmt(row.totalCsv)}</div>
            <div style={{fontSize:10,color:c.sub,marginTop:3}}>Total CSV</div>
          </div>
          {FILTERS.map(f=>{
            const isActive=active===f.id;
            return (
              <button key={f.id} onClick={()=>{setActive(f.id);setSearch("");}} style={{
                padding:"10px 18px",borderRadius:10,
                background:isActive?`${f.color}18`:c.met,
                border:isActive?`2px solid ${f.color}`:`2px solid transparent`,
                outline:"none",cursor:"pointer",textAlign:"center",minWidth:90,transition:"all .15s",
              }}>
                <div style={{fontSize:20,fontWeight:700,color:f.color}}>{fmt(f.value)}</div>
                <div style={{fontSize:10,color:isActive?f.color:c.sub,marginTop:3,fontWeight:isActive?600:400}}>{f.label}</div>
              </button>
            );
          })}
        </div>

        {/* Description */}
        <div style={{padding:"8px 22px 0"}}>
          <p style={{fontSize:12,color:c.sub,margin:0}}>
            {active==="matched"
              ? "These CSV property IDs were found and matched in the database (ptax_account_test)."
              : "These CSV property IDs were NOT found in the database — no matching account exists."}
          </p>
        </div>

        {/* Search */}
        <div style={{padding:"8px 22px",borderBottom:`1px solid ${c.bd}`}}>
          <div style={{display:"flex",alignItems:"center",gap:8,background:c.met,borderRadius:8,padding:"6px 12px"}}>
            <Search size={12} color={c.sub}/>
            <input value={search} onChange={e=>setSearch(e.target.value)}
              placeholder={`Search ${current.label.toLowerCase()} IDs…`}
              style={{flex:1,background:"transparent",border:"none",outline:"none",fontSize:12,color:c.txt}}
            />
            {search && <button onClick={()=>setSearch("")} style={{background:"transparent",border:"none",cursor:"pointer",color:c.sub,padding:0}}><X size={11}/></button>}
          </div>
          <div style={{fontSize:10,color:c.sub,marginTop:5}}>Showing {fmt(filtered.length)} of {fmt(current.pids.length)} IDs</div>
        </div>

        {/* PIDs */}
        <div style={{flex:1,overflow:"auto",padding:"10px 22px 16px"}}>
          {filtered.length===0
            ? <p style={{color:c.sub,fontSize:13,margin:0}}>No entries{search?" matching your search":""}.</p>
            : <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
                {filtered.map((pid,i)=>(
                  <span key={i} style={{
                    fontSize:11,padding:"3px 8px",fontFamily:"monospace",
                    background:`${current.color}14`,border:`1px solid ${current.color}44`,
                    borderRadius:5,color:current.color,
                  }}>{pid}</span>
                ))}
              </div>
          }
        </div>

        <div style={{padding:"10px 22px",borderTop:`1px solid ${c.bd}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <button onClick={exportCSV} style={{display:"flex",alignItems:"center",gap:6,padding:"6px 14px",background:"transparent",border:`1px solid ${c.bd}`,borderRadius:7,color:c.sub,fontSize:12,cursor:"pointer"}}>
            <Download size={12}/> Export CSV
          </button>
          <button onClick={onClose} style={{padding:"7px 20px",background:c.acc,border:"none",borderRadius:8,color:"#fff",fontSize:13,cursor:"pointer"}}>Close</button>
        </div>
      </div>
    </div>
  );
}

// ── Download Logs Row ────────────────────────────────────────────
function DownloadRow({ row, c, onTrigger }) {
  const [open,       setOpen]       = useState(false);
  const [viewOpen,   setViewOpen]   = useState(false);
  const [triggering, setTriggering] = useState(false);

  const handleDownload = () =>
    window.open(`${API}/automation/download-file?filepath=${encodeURIComponent(row.filepath)}`,"_blank");

  const handleTrigger = async () => {
    setTriggering(true);
    await onTrigger(row.county);
    setTriggering(false);
  };

  return (
    <>
      {viewOpen && <DownloadViewModal row={row} onClose={()=>setViewOpen(false)} c={c}/>}
      <div style={{background:c.card,border:`1px solid ${c.bd}`,borderRadius:10,marginBottom:8}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 100px 130px 90px 90px 90px 120px",alignItems:"center",gap:12,padding:"11px 16px"}}>
          <div>
            <div style={{fontWeight:600,fontSize:13}}>{row.county}</div>
            <div style={{fontSize:11,color:c.sub,marginTop:2,fontFamily:"monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{row.filename}</div>
          </div>
          <div style={{fontSize:12,color:c.sub}}>{toIST(row.time)}</div>
          <div style={{fontSize:12,color:c.sub,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{row.fileSize}</div>
          <div style={{fontSize:13,fontWeight:600}}>{fmt(row.totalCsv)}</div>
          <div style={{fontSize:12,fontWeight:600,color:c.green,display:"flex",alignItems:"center",gap:4}}><CheckCircle2 size={12}/> {fmt(row.matched)}</div>
          <div style={{fontSize:12,fontWeight:600,color:c.red,display:"flex",alignItems:"center",gap:4}}><XCircle size={12}/> {fmt((row.totalCsv||0)-(row.matched||0))}</div>
          <div style={{display:"flex",alignItems:"center",gap:6}}>
            <StatusBadge ok={row.status==="success"} c={c}/>
            <button onClick={()=>setViewOpen(true)} style={{background:"transparent",border:`1px solid ${c.acc}44`,borderRadius:6,padding:"4px 8px",cursor:"pointer",color:c.actTxt,display:"flex",alignItems:"center",gap:4,fontSize:11,fontWeight:600}}>
              <Eye size={11}/> View
            </button>
            <button onClick={handleDownload} style={{background:"transparent",border:`1px solid ${c.bd}`,borderRadius:6,padding:"4px 7px",cursor:"pointer",color:c.sub,display:"flex"}}><Download size={12}/></button>
            <button onClick={handleTrigger} disabled={triggering} style={{background:"transparent",border:`1px solid ${c.bd}`,borderRadius:6,padding:"4px 7px",cursor:"pointer",color:c.sub,display:"flex"}}><Play size={12} color={triggering?c.acc:c.sub}/></button>
            <button onClick={()=>setOpen(!open)} style={{background:"transparent",border:"none",cursor:"pointer",color:c.sub,display:"flex",padding:0}}>
              {open?<ChevronUp size={14}/>:<ChevronDown size={14}/>}
            </button>
          </div>
        </div>
        {open && (
          <div style={{borderTop:`1px solid ${c.bd}`,padding:"12px 16px",display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div>
              <div style={{fontSize:11,fontWeight:600,color:c.green,marginBottom:6}}>MATCHED ({fmt((row.successPids||[]).length)})</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:5,maxHeight:130,overflow:"auto"}}>
                {(row.successPids||[]).slice(0,200).map((pid,i)=>(
                  <span key={i} style={{fontSize:10,padding:"2px 6px",background:`${c.green}18`,border:`1px solid ${c.green}44`,borderRadius:4,color:c.green,fontFamily:"monospace"}}>{pid}</span>
                ))}
                {(row.successPids||[]).length>200 && <span style={{fontSize:10,color:c.sub,alignSelf:"center"}}>+{(row.successPids||[]).length-200} more — click View</span>}
              </div>
            </div>
            <div>
              <div style={{fontSize:11,fontWeight:600,color:c.red,marginBottom:6}}>UNMATCHED ({fmt((row.failPids||[]).length)})</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:5,maxHeight:130,overflow:"auto"}}>
                {(row.failPids||[]).slice(0,200).map((pid,i)=>(
                  <span key={i} style={{fontSize:10,padding:"2px 6px",background:`${c.red}18`,border:`1px solid ${c.red}44`,borderRadius:4,color:c.red,fontFamily:"monospace"}}>{pid}</span>
                ))}
                {(row.failPids||[]).length>200 && <span style={{fontSize:10,color:c.sub,alignSelf:"center"}}>+{(row.failPids||[]).length-200} more — click View</span>}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

// ── DB Logs Row ──────────────────────────────────────────────────
function DbRow({ row, c }) {
  const [viewOpen, setViewOpen] = useState(false);
  return (
    <>
      {viewOpen && <DbViewModal row={row} onClose={()=>setViewOpen(false)} c={c}/>}
      <div style={{background:c.card,border:`1px solid ${c.bd}`,borderRadius:10,marginBottom:8}}>
        <div style={{display:"grid",gridTemplateColumns:"1.4fr 100px 90px 110px 110px 100px 110px 70px",alignItems:"center",gap:12,padding:"13px 16px"}}>
          <div>
            <div style={{fontWeight:600,fontSize:13}}>{row.county}</div>
            <div style={{fontSize:11,color:c.sub,marginTop:2}}>{toISTDate(row.date)}</div>
          </div>
          <div style={{fontSize:12,color:c.sub}}>{toIST(row.time)}</div>
          <div style={{fontSize:13,fontWeight:700,color:c.txt}}>{fmt(row.totalAccounts)}</div>
          <div>
            <div style={{fontSize:12,fontWeight:700,color:c.acc}}>{fmt(row.datecodedUpdated)}</div>
            <div style={{fontSize:10,color:c.sub,marginTop:1}}>accounts updated</div>
          </div>
          <div>
            <div style={{fontSize:12,fontWeight:700,color:c.red}}>{fmt(row.datecodedEnd)}</div>
            <div style={{fontSize:10,color:c.sub,marginTop:1}}>accounts expired</div>
          </div>
          <div>
            <div style={{fontSize:12,fontWeight:700,color:c.green}}>{fmt(row.insertedCount)}</div>
            <div style={{fontSize:10,color:c.sub,marginTop:1}}>new accounts</div>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:3}}>
            <div style={{display:"flex",alignItems:"center",gap:4,fontSize:11,fontWeight:600,color:c.green}}>
              <CheckCircle2 size={11}/> {fmt(row.successCount)} matched
            </div>
            <div style={{display:"flex",alignItems:"center",gap:4,fontSize:11,fontWeight:600,color:c.red}}>
              <XCircle size={11}/> {fmt(row.failureCount)} unmatched
            </div>
          </div>
          <button onClick={()=>setViewOpen(true)} style={{
            display:"flex",alignItems:"center",gap:5,
            padding:"6px 12px",background:c.actBg,
            border:`1px solid ${c.acc}44`,borderRadius:7,
            color:c.actTxt,fontSize:12,fontWeight:600,cursor:"pointer",
          }}><Eye size={13}/> View</button>
        </div>
      </div>
    </>
  );
}

// ── Date filter pills ────────────────────────────────────────────
function DateFilter({ value, onSelect, onCalendar, c }) {
  return (
    <div style={{display:"flex",gap:6,alignItems:"center"}}>
      {[{label:"Today",value:"today"},{label:"Yesterday",value:"yesterday"}].map(opt=>(
        <button key={opt.value} onClick={()=>onSelect(opt.value)} style={{
          padding:"5px 14px",borderRadius:20,fontSize:12,fontWeight:500,
          border:`1px solid ${value===opt.value?c.acc:c.bd}`,
          background:value===opt.value?c.actBg:"transparent",
          color:value===opt.value?c.actTxt:c.sub,cursor:"pointer",
        }}>{opt.label}</button>
      ))}
      <CalendarPicker
        value={typeof value==="string"&&value.match(/^\d{4}-\d{2}-\d{2}$/)?value:""}
        onConfirm={onCalendar} c={c}
      />
    </div>
  );
}

function latestPerCounty(rows) {
  if (!Array.isArray(rows)) return [];
  const map = {};
  for (const row of rows) {
    if (!map[row.county]||row.time>map[row.county].time) map[row.county]=row;
  }
  return Object.values(map);
}

// ── Main AutomationPage ──────────────────────────────────────────
export default function AutomationPage({ c }) {
  const [tab,            setTab]            = useState("download");
  const [dlFilter,       setDlFilter]       = useState("today");
  const [selectedCounties, setSelectedCounties] = useState([]);
  const [dlLogs,         setDlLogs]         = useState([]);
  const [dbLogs,         setDbLogs]         = useState([]);
  const [loading,        setLoading]        = useState(false);
  const [error,          setError]          = useState(null);
  const [triggerMsg,     setTriggerMsg]     = useState(null);

  const fetchLogs = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [dlRes,dbRes] = await Promise.all([
        fetch(`${API}/automation/download-logs?date_filter=${dlFilter}`,{headers:NGROK_HEADERS}),
        fetch(`${API}/automation/db-logs?date_filter=today`,            {headers:NGROK_HEADERS}),
      ]);
      const dlData = await dlRes.json();
      const dbData = await dbRes.json();
      setDlLogs(Array.isArray(dlData) ? dlData : []);
      setDbLogs(Array.isArray(dbData) ? dbData : []);
    } catch {
      setError("Could not reach backend. Make sure FastAPI is running on port 8000.");
    }
    setLoading(false);
  }, [dlFilter]);

  useEffect(()=>{fetchLogs();},[fetchLogs]);
  useEffect(()=>{setSelectedCounties([]);},[tab]);

  const handleTrigger = async (county) => {
    try {
      const res  = await fetch(`${API}/automation/trigger`,{
        method:"POST",headers:{...NGROK_HEADERS,"Content-Type":"application/json"},
        body:JSON.stringify({county}),
      });
      const data = await res.json();
      setTriggerMsg(data.message||`${county} triggered`);
      setTimeout(()=>setTriggerMsg(null),3000);
      fetchLogs();
    } catch {
      setTriggerMsg("Trigger failed — check backend");
      setTimeout(()=>setTriggerMsg(null),3000);
    }
  };

  const dlSuccess  = dlLogs.filter(r=>r.status==="success").length;
  const dlError    = dlLogs.filter(r=>r.status!=="success").length;
  const dlTotal    = dlLogs.reduce((s,r)=>s+(r.totalCsv||0),0);
  const dlMatched  = dlLogs.reduce((s,r)=>s+(r.matched||0),0);

  const uniqueDbLogs = latestPerCounty(dbLogs);
  const dbCounties   = uniqueDbLogs.length;
  const dbTotal      = uniqueDbLogs.reduce((s,r)=>s+(r.totalAccounts||0),0);
  const dbDatecoded  = uniqueDbLogs.reduce((s,r)=>s+(r.datecodedUpdated||0),0);
  const dbExpired    = uniqueDbLogs.reduce((s,r)=>s+(r.datecodedEnd||0),0);
  const dbInserted   = uniqueDbLogs.reduce((s,r)=>s+(r.insertedCount||0),0);

  const allCounties = [...new Set((tab==="download"?dlLogs:uniqueDbLogs).map(r=>r.county))].sort();
  const noFilter    = selectedCounties.length===0||selectedCounties.length===allCounties.length;
  const visibleDl   = noFilter ? dlLogs       : dlLogs.filter(r=>selectedCounties.includes(r.county));
  const visibleDb   = noFilter ? uniqueDbLogs : uniqueDbLogs.filter(r=>selectedCounties.includes(r.county));

  const card = (label,value,color,Icon)=>(
    <div style={{background:c.card,border:`1px solid ${c.bd}`,borderRadius:12,padding:"16px 20px"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
        <span style={{fontSize:11,color:c.sub,fontWeight:500}}>{label}</span>
        <Icon size={14} color={color} strokeWidth={1.75}/>
      </div>
      <div style={{fontSize:26,fontWeight:700,letterSpacing:-0.8,color}}>{value}</div>
    </div>
  );
  const colHdr=(label,style={})=>(
    <div style={{fontSize:10,fontWeight:600,letterSpacing:"0.06em",color:c.mut,...style}}>{label}</div>
  );

  return (
    <div style={{flex:1,overflow:"auto",padding:"26px 28px"}}>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>

      {/* Header */}
      <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:20}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:700,marginBottom:4}}>Automation</h1>
          <p style={{fontSize:13,color:c.sub}}>County data downloads and database sync logs</p>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          {tab==="download" && <DateFilter value={dlFilter} onSelect={setDlFilter} onCalendar={setDlFilter} c={c}/>}
          <button onClick={fetchLogs} style={{display:"flex",alignItems:"center",gap:6,padding:"7px 14px",background:"transparent",border:`1px solid ${c.bd}`,borderRadius:8,color:c.sub,fontSize:12,cursor:"pointer"}}>
            <RefreshCw size={12} style={{animation:loading?"spin 1s linear infinite":"none"}}/> Refresh
          </button>
        </div>
      </div>

      {triggerMsg && <div style={{marginBottom:14,padding:"10px 16px",background:c.actBg,border:`1px solid ${c.acc}44`,borderRadius:9,fontSize:13,color:c.actTxt}}>{triggerMsg}</div>}
      {error && <div style={{marginBottom:14,padding:"10px 16px",background:`${c.red}18`,border:`1px solid ${c.red}44`,borderRadius:9,fontSize:13,color:c.red,display:"flex",alignItems:"center",gap:8}}><AlertCircle size={14}/> {error}</div>}

      {/* Tab toggle + county dropdown on same row */}
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16}}>
        <div style={{display:"flex",gap:0,background:c.met,borderRadius:10,padding:4,width:"fit-content"}}>
          {[{id:"download",label:"Download Logs",Icon:Download},{id:"db",label:"DB Update Logs",Icon:Database}].map(({id,label,Icon})=>(
            <button key={id} onClick={()=>setTab(id)} style={{
              display:"flex",alignItems:"center",gap:7,padding:"7px 20px",borderRadius:8,border:"none",
              background:tab===id?c.card:"transparent",
              color:tab===id?c.actTxt:c.sub,
              fontWeight:tab===id?600:400,fontSize:13,
              boxShadow:tab===id?`0 0 0 1px ${c.bd}`:"none",cursor:"pointer",
            }}><Icon size={13}/> {label}</button>
          ))}
        </div>

        {/* County dropdown — always visible */}
        {allCounties.length>0 && (
          <CountyDropdown
            counties={allCounties}
            selected={selectedCounties}
            onChange={setSelectedCounties}
            c={c}
          />
        )}
      </div>

      {/* ══ DOWNLOAD TAB ══ */}
      {tab==="download" && <>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,minmax(0,1fr))",gap:12,marginBottom:20}}>
          {card("Successful Downloads",dlSuccess,c.green,CheckCircle2)}
          {card("Failed Downloads",dlError,c.red,XCircle)}
          {card("Total CSV Records",fmt(dlTotal),c.acc,FileText)}
          {card("Matched in DB",fmt(dlMatched),c.sub,Database)}
        </div>
        {loading
          ? <div style={{color:c.sub,fontSize:13,padding:"20px 0"}}>Loading…</div>
          : visibleDl.length===0
            ? <div style={{color:c.sub,fontSize:13,padding:"20px 0"}}>No download logs found for this period.</div>
            : <>
                <div style={{display:"grid",gridTemplateColumns:"1fr 100px 130px 90px 90px 90px 120px",gap:12,padding:"0 16px 8px"}}>
                  {colHdr("COUNTY / FILE")}{colHdr("TIME (IST)")}{colHdr("FILE SIZE")}{colHdr("CSV ROWS")}{colHdr("MATCHED")}{colHdr("FAILED")}{colHdr("ACTIONS")}
                </div>
                {visibleDl.map(row=><DownloadRow key={row.id} row={row} c={c} onTrigger={handleTrigger}/>)}
              </>
        }
      </>}

      {/* ══ DB UPDATE TAB ══ */}
      {tab==="db" && <>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
          <span style={{fontSize:12,fontWeight:600,padding:"4px 12px",borderRadius:20,background:c.actBg,color:c.actTxt,border:`1px solid ${c.acc}44`}}>
            📅 Today's Status — Latest run per county
          </span>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(5,minmax(0,1fr))",gap:12,marginBottom:20}}>
          {card("Counties Updated",dbCounties,c.acc,Database)}
          {card("Total Accounts",fmt(dbTotal),c.sub,TrendingUp)}
          {card("DateCoded Updated",fmt(dbDatecoded),c.acc,Clock)}
          {card("DateCoded Expired",fmt(dbExpired),c.red,XCircle)}
          {card("New Inserted",fmt(dbInserted),c.green,CheckCircle2)}
        </div>
        {loading
          ? <div style={{color:c.sub,fontSize:13,padding:"20px 0"}}>Loading…</div>
          : visibleDb.length===0
            ? <div style={{color:c.sub,fontSize:13,padding:"20px 0"}}>No DB update logs found for today.</div>
            : <>
                <div style={{display:"grid",gridTemplateColumns:"1.4fr 100px 90px 110px 110px 100px 110px 70px",gap:12,padding:"0 16px 8px"}}>
                  {colHdr("COUNTY")}{colHdr("TIME (IST)")}{colHdr("TOTAL")}{colHdr("DATECODED")}{colHdr("DATEENDED")}{colHdr("INSERTED")}{colHdr("STATUS")}{colHdr("VIEW")}
                </div>
                {visibleDb.map(row=><DbRow key={row.id} row={row} c={c}/>)}
              </>
        }
      </>}
    </div>
  );
}
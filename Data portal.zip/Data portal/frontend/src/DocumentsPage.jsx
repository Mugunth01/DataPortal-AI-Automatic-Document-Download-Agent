/**
 * DocumentsPage.jsx
 *
 * Upload CSV/XLSX manually → backend extracts property IDs
 * → runs the same DB update process as autodownload.py
 * → shows last 5 uploads with live status + result stats
 */

import { useState, useEffect, useRef, useCallback } from "react";
import {
  Upload, FileText, CheckCircle2, XCircle, Clock,
  Database, AlertCircle, RefreshCw, Eye, X, Trash2,
  Download, Search,
} from "lucide-react";

// ── Backend ngrok URL (same as App.jsx) ──────────────────────────
const API = "https://61ad-111-93-110-218.ngrok-free.app";
const NGROK_HEADERS = { "ngrok-skip-browser-warning": "true" };

const fmt = (n) => (n ?? 0).toLocaleString();

function toIST(timeStr) {
  return timeStr ? `${timeStr} IST` : "—";
}
function toISTDate(dateStr) {
  if (!dateStr) return "—";
  try {
    const [y, m, d] = dateStr.split("-");
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return `${d} ${months[parseInt(m,10)-1]} ${y}`;
  } catch { return dateStr; }
}

// ── Status badge ─────────────────────────────────────────────────
function StatusBadge({ status, c }) {
  const cfg = {
    success:    { bg: `${c.green}20`, color: c.green,  icon: <CheckCircle2 size={11}/>, label: "Success"    },
    processing: { bg: `${c.acc}20`,   color: c.acc,    icon: <RefreshCw size={11} style={{animation:"spin 1s linear infinite"}}/>, label: "Processing…" },
    error:      { bg: `${c.red}20`,   color: c.red,    icon: <XCircle size={11}/>,      label: "Error"      },
    pending:    { bg: `${c.sub}18`,   color: c.sub,    icon: <Clock size={11}/>,         label: "Pending"    },
  }[status] || { bg: `${c.sub}18`, color: c.sub, icon: <Clock size={11}/>, label: status };

  return (
    <span style={{
      display:"inline-flex", alignItems:"center", gap:5,
      fontSize:11, fontWeight:600, padding:"3px 10px", borderRadius:20,
      background: cfg.bg, color: cfg.color,
    }}>
      {cfg.icon} {cfg.label}
    </span>
  );
}

// ── PID View Modal — stat chips ARE the filter, no separate tab bar, no Inserted ──
function PidModal({ upload, onClose, c }) {
  // 4 filters only — no Inserted
  const FILTERS = [
    { id:"success",  label:"Matched",    pids:upload.successPids||[], value:upload.successCount||0,     color:c.green },
    { id:"failure",  label:"Unmatched",  pids:upload.failurePids||[], value:upload.failureCount||0,     color:c.red   },
    { id:"updated",  label:"DateCoded ↑",pids:upload.updatedPids||[], value:upload.datecodedUpdated||0, color:c.acc   },
    { id:"expired",  label:"DateEnd ↑",  pids:upload.expiredPids||[], value:upload.datecodedEnd||0,     color:c.red   },
  ];

  const [active, setActive] = useState("success");
  const [search, setSearch] = useState("");

  const current  = FILTERS.find(f=>f.id===active)||FILTERS[0];
  const filtered = search.trim()
    ? current.pids.filter(p=>p.toLowerCase().includes(search.trim().toLowerCase()))
    : current.pids;

  const exportCSV = () => {
    const blob = new Blob([filtered.join("\n")],{type:"text/csv"});
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href=url; a.download=`${upload.county}_${active}_${upload.date}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div onClick={onClose} style={{
      position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",
      zIndex:400,display:"flex",alignItems:"center",justifyContent:"center",
    }}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:c.card,border:`1px solid ${c.bd}`,
        borderRadius:16,width:660,maxHeight:"84vh",
        display:"flex",flexDirection:"column",overflow:"hidden",
        boxShadow:"0 24px 64px rgba(0,0,0,0.3)",
      }}>
        {/* Header */}
        <div style={{padding:"18px 22px",borderBottom:`1px solid ${c.bd}`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div>
            <div style={{fontWeight:700,fontSize:15}}>{upload.filename} — DB Results</div>
            <div style={{fontSize:11,color:c.sub,marginTop:3}}>
              County: {upload.county} · {toISTDate(upload.date)} {toIST(upload.time)}
            </div>
          </div>
          <button onClick={onClose} style={{background:"transparent",border:"none",cursor:"pointer",color:c.sub}}>
            <X size={18}/>
          </button>
        </div>

        {/* ── Clickable stat chips — these ARE the filter ── */}
        <div style={{display:"flex",gap:10,padding:"14px 22px",borderBottom:`1px solid ${c.bd}`,flexWrap:"wrap"}}>
          {/* Total Accounts — info only, not a filter */}
          <div style={{padding:"10px 18px",borderRadius:10,background:c.met,border:`1px solid ${c.bd}`,textAlign:"center",minWidth:90}}>
            <div style={{fontSize:20,fontWeight:700,color:c.txt}}>{fmt(upload.totalAccounts)}</div>
            <div style={{fontSize:10,color:c.sub,marginTop:3}}>Total Accounts</div>
          </div>

          {FILTERS.map(f=>{
            const isActive=active===f.id;
            return (
              <button key={f.id} onClick={()=>{setActive(f.id);setSearch("");}} style={{
                padding:"10px 18px",borderRadius:10,
                background:isActive?`${f.color}18`:c.met,
                border:isActive?`2px solid ${f.color}`:`2px solid transparent`,
                outline:"none",cursor:"pointer",textAlign:"center",minWidth:90,
                transition:"all .15s",
              }}>
                <div style={{fontSize:20,fontWeight:700,color:f.color}}>{fmt(f.value)}</div>
                <div style={{fontSize:10,color:isActive?f.color:c.sub,marginTop:3,fontWeight:isActive?600:400}}>{f.label}</div>
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div style={{padding:"10px 22px 8px",borderBottom:`1px solid ${c.bd}`}}>
          <div style={{display:"flex",alignItems:"center",gap:8,background:c.met,borderRadius:8,padding:"6px 12px"}}>
            <Search size={12} color={c.sub}/>
            <input
              value={search} onChange={e=>setSearch(e.target.value)}
              placeholder={`Search ${current.label} IDs…`}
              style={{flex:1,background:"transparent",border:"none",outline:"none",fontSize:12,color:c.txt}}
            />
            {search && <button onClick={()=>setSearch("")} style={{background:"transparent",border:"none",cursor:"pointer",color:c.sub,padding:0}}><X size={11}/></button>}
          </div>
          <div style={{fontSize:10,color:c.sub,marginTop:5}}>
            Showing {fmt(filtered.length)} of {fmt(current.pids.length)} IDs
          </div>
        </div>

        {/* PIDs */}
        <div style={{flex:1,overflow:"auto",padding:"12px 22px 16px"}}>
          {filtered.length===0
            ? <p style={{color:c.sub,fontSize:13,margin:0}}>No entries{search?" matching your search":""}.</p>
            : <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
                {filtered.map((pid,i)=>(
                  <span key={i} style={{
                    fontSize:11,padding:"3px 8px",fontFamily:"monospace",
                    background:`${current.color}14`,border:`1px solid ${current.color}44`,
                    borderRadius:5,color:current.color,
                  }}>{pid}</span>
                ))}
              </div>
          }
        </div>

        {/* Footer */}
        <div style={{padding:"10px 22px",borderTop:`1px solid ${c.bd}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <button onClick={exportCSV} style={{display:"flex",alignItems:"center",gap:6,padding:"6px 14px",background:"transparent",border:`1px solid ${c.bd}`,borderRadius:7,color:c.sub,fontSize:12,cursor:"pointer"}}>
            <Download size={12}/> Export CSV
          </button>
          <button onClick={onClose} style={{padding:"7px 20px",background:c.acc,border:"none",borderRadius:8,color:"#fff",fontSize:13,cursor:"pointer"}}>Close</button>
        </div>
      </div>
    </div>
  );
}

// ── Upload History Row ───────────────────────────────────────────
function UploadRow({ upload, c, onView, onDelete }) {
  return (
    <div style={{
      background:c.card, border:`1px solid ${c.bd}`,
      borderRadius:12, padding:"14px 18px",
      display:"flex", alignItems:"center", gap:14,
      transition:"box-shadow .15s",
    }}>
      {/* Icon */}
      <div style={{
        width:40,height:40,borderRadius:10,flexShrink:0,
        background: upload.status==="success" ? `${c.green}18` : upload.status==="error" ? `${c.red}18` : `${c.acc}18`,
        display:"flex",alignItems:"center",justifyContent:"center",
      }}>
        <FileText size={18} color={
          upload.status==="success" ? c.green : upload.status==="error" ? c.red : c.acc
        } strokeWidth={1.75}/>
      </div>

      {/* File info */}
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontWeight:600,fontSize:13,overflow:"hidden",whiteSpace:"nowrap",textOverflow:"ellipsis"}}>
          {upload.filename}
        </div>
        <div style={{fontSize:11,color:c.sub,marginTop:3}}>
          {upload.county && <span style={{marginRight:10}}>📍 {upload.county}</span>}
          {toISTDate(upload.date)} · {toIST(upload.time)}
          {upload.fileSize && <span style={{marginLeft:10}}>· {upload.fileSize}</span>}
        </div>
      </div>

      {/* Stats mini */}
      {upload.status==="success" && (
        <div style={{display:"flex",gap:16,flexShrink:0}}>
          <div style={{textAlign:"center"}}>
            <div style={{fontSize:14,fontWeight:700,color:c.txt}}>{fmt(upload.totalCsv)}</div>
            <div style={{fontSize:9,color:c.sub,marginTop:1}}>CSV ROWS</div>
          </div>
          <div style={{textAlign:"center"}}>
            <div style={{fontSize:14,fontWeight:700,color:c.green}}>{fmt(upload.successCount)}</div>
            <div style={{fontSize:9,color:c.sub,marginTop:1}}>MATCHED</div>
          </div>
          <div style={{textAlign:"center"}}>
            <div style={{fontSize:14,fontWeight:700,color:c.red}}>{fmt(upload.failureCount)}</div>
            <div style={{fontSize:9,color:c.sub,marginTop:1}}>UNMATCHED</div>
          </div>
          <div style={{textAlign:"center"}}>
            <div style={{fontSize:14,fontWeight:700,color:c.acc}}>{fmt(upload.datecodedUpdated)}</div>
            <div style={{fontSize:9,color:c.sub,marginTop:1}}>UPDATED</div>
          </div>
        </div>
      )}

      {upload.status==="processing" && (
        <div style={{fontSize:12,color:c.acc,display:"flex",alignItems:"center",gap:6}}>
          <RefreshCw size={13} style={{animation:"spin 1s linear infinite"}}/> Running DB update…
        </div>
      )}

      {upload.status==="error" && upload.error && (
        <div style={{fontSize:11,color:c.red,maxWidth:200,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
          {upload.error}
        </div>
      )}

      {/* Status + actions */}
      <div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
        <StatusBadge status={upload.status} c={c}/>
        {upload.status==="success" && (
          <button onClick={()=>onView(upload)} style={{
            display:"flex",alignItems:"center",gap:5,
            padding:"5px 12px",background:c.actBg,
            border:`1px solid ${c.acc}44`,borderRadius:7,
            color:c.actTxt,fontSize:12,fontWeight:600,cursor:"pointer",
          }}>
            <Eye size={12}/> View
          </button>
        )}
        <button onClick={()=>onDelete(upload.id)} style={{
          background:"transparent",border:`1px solid ${c.bd}`,
          borderRadius:6,padding:"5px 7px",cursor:"pointer",
          color:c.sub,display:"flex",
        }}>
          <Trash2 size={12}/>
        </button>
      </div>
    </div>
  );
}

// ── County selector (optional, for manual county mapping) ────────
const COUNTY_OPTIONS = [
  {value:"Bell",     label:"Bell"},
  {value:"Starr",    label:"Starr"},
  {value:"Brown",    label:"Brown"},
  {value:"Brooks",   label:"Brooks"},
  {value:"Brewster", label:"Brewster"},
];

// ── Main DocumentsPage ───────────────────────────────────────────
export default function DocumentsPage({ c }) {
  const [uploads, setUploads]       = useState([]);   // last 5
  const [dragging, setDragging]     = useState(false);
  const [uploading, setUploading]   = useState(false);
  const [error, setError]           = useState(null);
  const [viewModal, setViewModal]   = useState(null);
  const [county, setCounty]         = useState("Bell");
  const fileRef = useRef(null);

  // Load history from localStorage on mount
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("doc_uploads") || "[]");
      setUploads(saved);
    } catch {}
  }, []);

  const saveUploads = (list) => {
    setUploads(list);
    localStorage.setItem("doc_uploads", JSON.stringify(list));
  };

  // ── Poll for processing status ──────────────────────────────
  useEffect(() => {
    const processing = uploads.filter(u => u.status === "processing");
    if (processing.length === 0) return;

    const interval = setInterval(async () => {
      const updated = [...uploads];
      let changed = false;

      for (const u of processing) {
        try {
          const res = await fetch(`${API}/documents/status/${u.id}`, { headers: NGROK_HEADERS });
          if (!res.ok) continue;
          const data = await res.json();
          const idx = updated.findIndex(x => x.id === u.id);
          if (idx !== -1 && data.status !== "processing") {
            updated[idx] = { ...updated[idx], ...data };
            changed = true;
          }
        } catch {}
      }

      if (changed) saveUploads(updated);
    }, 3000);

    return () => clearInterval(interval);
  }, [uploads]);

  // ── Handle file upload ──────────────────────────────────────
  const handleFile = async (file) => {
    if (!file) return;
    const allowed = ["text/csv", "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/octet-stream"];
    const ext = file.name.split(".").pop().toLowerCase();
    if (!["csv","xlsx","xls"].includes(ext)) {
      setError("Only CSV or Excel (.xlsx/.xls) files are supported.");
      return;
    }

    setError(null);
    setUploading(true);

    const formData = new FormData();
    formData.append("file", file);
    formData.append("county", county);

    // Optimistic entry
    const tempId = `upload_${Date.now()}`;
    const tempEntry = {
      id:         tempId,
      filename:   file.name,
      fileSize:   `${(file.size / (1024*1024)).toFixed(2)} MB`,
      county:     county,
      status:     "processing",
      date:       new Date().toLocaleDateString("sv-SE"), // YYYY-MM-DD
      time:       new Date().toLocaleTimeString("en-IN", {hour:"2-digit",minute:"2-digit",hour12:false}),
      totalCsv:   0, successCount:0, failureCount:0,
      datecodedUpdated:0, datecodedEnd:0, insertedCount:0, totalAccounts:0,
      successPids:[], failurePids:[], updatedPids:[], expiredPids:[], insertedPids:[],
    };

    const newList = [tempEntry, ...uploads].slice(0, 5);
    saveUploads(newList);

    try {
      const res = await fetch(`${API}/documents/upload`, {
        method: "POST",
        headers: { ...NGROK_HEADERS },  // NO Content-Type — let browser set multipart boundary
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: "Upload failed" }));
        throw new Error(err.detail || "Upload failed");
      }

      const data = await res.json();
      // Merge result into the temp entry
      const merged = {
        ...tempEntry,
        id:               data.id || tempId,
        status:           data.status || "success",
        totalCsv:         data.totalCsv         ?? 0,
        totalAccounts:    data.totalAccounts     ?? 0,
        successCount:     data.successCount      ?? 0,
        failureCount:     data.failureCount      ?? 0,
        datecodedUpdated: data.datecodedUpdated  ?? 0,
        datecodedEnd:     data.datecodedEnd      ?? 0,
        insertedCount:    data.insertedCount     ?? 0,
        successPids:      data.successPids       ?? [],
        failurePids:      data.failurePids       ?? [],
        updatedPids:      data.updatedPids       ?? [],
        expiredPids:      data.expiredPids       ?? [],
        insertedPids:     data.insertedPids      ?? [],
        error:            data.error,
      };

      const finalList = newList.map(u => u.id === tempId ? merged : u);
      saveUploads(finalList);

    } catch (e) {
      const errList = newList.map(u =>
        u.id === tempId ? { ...u, status:"error", error: e.message } : u
      );
      saveUploads(errList);
      setError(e.message);
    }

    setUploading(false);
  };

  const handleDrop = (e) => {
    e.preventDefault(); setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const handleDelete = (id) => {
    saveUploads(uploads.filter(u => u.id !== id));
  };

  // ── Stats from latest successful upload ──────────────────────
  const latest = uploads.find(u => u.status === "success");

  return (
    <div style={{ flex:1, overflow:"auto", padding:"26px 28px" }}>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>

      {/* Header */}
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:22 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:700, marginBottom:4 }}>Documents</h1>
          <p style={{ fontSize:13, color:c.sub }}>Upload CSV or Excel files to run DB property update</p>
        </div>
        <button
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          style={{
            display:"flex", alignItems:"center", gap:7,
            padding:"9px 18px", background: uploading ? c.met : c.acc,
            border:"none", borderRadius:9, color: uploading ? c.sub : "#fff",
            fontSize:13, fontWeight:600, cursor: uploading ? "not-allowed" : "pointer",
          }}
        >
          {uploading
            ? <><RefreshCw size={14} style={{animation:"spin 1s linear infinite"}}/> Uploading…</>
            : <><Upload size={14}/> Upload File</>
          }
        </button>
        <input ref={fileRef} type="file" accept=".csv,.xlsx,.xls" style={{display:"none"}}
          onChange={e => handleFile(e.target.files[0])}/>
      </div>

      {/* Error banner */}
      {error && (
        <div style={{
          marginBottom:16, padding:"10px 16px",
          background:`${c.red}14`, border:`1px solid ${c.red}44`,
          borderRadius:9, fontSize:13, color:c.red,
          display:"flex", alignItems:"center", gap:8,
        }}>
          <AlertCircle size={14}/> {error}
          <button onClick={()=>setError(null)} style={{marginLeft:"auto",background:"transparent",border:"none",color:c.red,cursor:"pointer"}}>
            <X size={14}/>
          </button>
        </div>
      )}

      {/* County selector + drop zone */}
      <div style={{
        border:`2px dashed ${dragging ? c.acc : c.bd}`,
        borderRadius:14, padding:"28px 32px",
        textAlign:"center", marginBottom:24,
        background: dragging ? `${c.acc}08` : c.met,
        transition:"all .2s", cursor:"pointer",
      }}
        onClick={() => fileRef.current?.click()}
        onDragOver={e=>{e.preventDefault();setDragging(true)}}
        onDragLeave={()=>setDragging(false)}
        onDrop={handleDrop}
      >
        <Upload size={32} color={dragging ? c.acc : c.mut} style={{marginBottom:10}}/>
        <div style={{fontSize:15, fontWeight:600, marginBottom:6, color: dragging ? c.acc : c.txt}}>
          {dragging ? "Drop file here…" : "Drop CSV or Excel file here"}
        </div>
        <div style={{fontSize:12, color:c.sub, marginBottom:16}}>
          or click to browse · supports .csv, .xlsx, .xls
        </div>

        {/* County picker inside drop zone */}
        <div
          onClick={e=>e.stopPropagation()}
          style={{display:"inline-flex",alignItems:"center",gap:10,
            padding:"8px 16px", background:c.card,
            border:`1px solid ${c.bd}`, borderRadius:10,
          }}
        >
          <Database size={13} color={c.acc}/>
          <span style={{fontSize:12,color:c.sub,fontWeight:500}}>County:</span>
          <select
            value={county}
            onChange={e=>setCounty(e.target.value)}
            style={{
              background:"transparent",border:"none",
              color:c.txt, fontSize:13, fontWeight:600,
              outline:"none", cursor:"pointer",
            }}
          >
            {COUNTY_OPTIONS.map(o=>(
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* What happens info banner */}
      <div style={{
        marginBottom:22, padding:"12px 16px",
        background:c.actBg, border:`1px solid ${c.acc}33`,
        borderRadius:10, fontSize:12, color:c.actTxt,
        display:"flex", alignItems:"flex-start", gap:10,
      }}>
        <Database size={14} style={{flexShrink:0,marginTop:1}}/>
        <div>
          <strong>What happens when you upload:</strong>{" "}
          Property IDs are extracted from your file → loaded into{" "}
          <code style={{fontFamily:"monospace",fontSize:11}}>PTAX_AofA_Staging</code> →{" "}
          <code style={{fontFamily:"monospace",fontSize:11}}>USP_Update_DateCoded_Fast</code> runs →
          accounts are <strong>updated</strong> (DateCoded set), <strong>expired</strong> (DateCodedEnd set),
          or <strong>inserted</strong> (new rows added) in{" "}
          <code style={{fontFamily:"monospace",fontSize:11}}>PTAX_AofA_Test</code>.
        </div>
      </div>

      {/* Recent uploads — last 5 */}
      <div style={{marginBottom:14,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <h2 style={{fontSize:14,fontWeight:700}}>
          Recent Uploads
          <span style={{
            marginLeft:8,fontSize:11,fontWeight:500,
            padding:"2px 8px",borderRadius:10,
            background:c.met,color:c.sub,
          }}>{uploads.length} / 5</span>
        </h2>
        {uploads.length > 0 && (
          <button
            onClick={()=>saveUploads([])}
            style={{fontSize:11,color:c.sub,background:"transparent",border:"none",cursor:"pointer",display:"flex",alignItems:"center",gap:4}}
          >
            <Trash2 size={11}/> Clear all
          </button>
        )}
      </div>

      {uploads.length === 0 ? (
        <div style={{
          padding:"40px 20px", textAlign:"center",
          border:`1px dashed ${c.bd}`, borderRadius:12,
          color:c.sub, fontSize:13,
        }}>
          <FileText size={28} color={c.mut} style={{marginBottom:12}}/>
          <div>No uploads yet. Upload a CSV or Excel file to get started.</div>
        </div>
      ) : (
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {uploads.map(upload=>(
            <UploadRow
              key={upload.id}
              upload={upload}
              c={c}
              onView={setViewModal}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      {/* PID view modal */}
      {viewModal && (
        <PidModal upload={viewModal} onClose={()=>setViewModal(null)} c={c}/>
      )}
    </div>
  );
}
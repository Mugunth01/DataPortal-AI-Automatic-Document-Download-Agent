// ─────────────────────────────────────────────────────────────────
//  config.js  ─  Central API configuration
//  UPDATE ONLY THIS FILE when ngrok URL changes
// ─────────────────────────────────────────────────────────────────

export const API = "https://d5f4-111-93-110-218.ngrok-free.app";

export const NGROK_HEADERS = {
  "ngrok-skip-browser-warning": "true",
};